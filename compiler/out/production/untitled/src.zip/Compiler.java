/**
 * @author zwzk8
 */
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Map;
import java.util.HashMap;
import java.util.Objects;
import line.*;
public class Compiler {
    static int pointer=0;
    static ArrayList<Token> tokenList = new ArrayList<>();
    static ArrayList<Token> tokenListPlus = new ArrayList<Token>();
    static ArrayList<Error> errorList = new ArrayList<Error>();
    static ArrayList<Table> tableList = new ArrayList<>();
    static ArrayList<Line> lineList = new ArrayList<Line>();
    static ArrayList<TreeNode> stack = new ArrayList<TreeNode>();
    static ArrayList<String> stringStack = new ArrayList<String>();
    static Table table0 = new Table(0,-1);
    static Token token0;
    static Error error0;
    static int line=1;
    static int tableId = 0;
    static int level = 0;
    static int regId = 1;
    static int nowTag = 0;
    static String tab = "   ";
    static HashMap <String,TreeNode> global= new HashMap <> ();
    static TreeNode root_compUnit = new TreeNode(0,0,"<CompUnit>");
    static TreeNode child = new TreeNode();
    public static void main(String[] args) {
        Token token0;
        String inputFile = "testfile.txt";
        String outputFile = "output1.txt";
        String str;
        int line=1;
        int p=0;
        tableList.add(table0);

        lineList.add(new Line(0,"declare i32 @getint()"));
        lineList.add(new Line(0,"declare void @putint(i32)"));
        lineList.add(new Line(0,"declare void @putch(i32)"));
        lineList.add(new Line(0,"declare void @putstr(i8*)"));

        //最外层的符号表，所有的函数、全局变量、全局常量都在这里
        //Table outermostTable = new Table(0,-1);
        //表明现在处于的符号表的id
        //tableList.add(outermostTable);

        try {
            // 创建文件读取流
            BufferedReader reader = new BufferedReader(new FileReader(inputFile));
            // 创建文件写入流
            BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile));
            StringBuilder fileContent = new StringBuilder();
            while ((str = reader.readLine()) != null) {
                // 将每行内容追加到fileContent中，可以根据需要添加换行符
                fileContent.append(str).append("\n");
            }
            str = fileContent.toString();
            str=removeMultiLineComments(str);
            str=removeSingleLineComments(str);
            System.out.println(str);
            while(p<str.length()){
                switch (str.charAt(p)){
                    case ' ':

                        break;
                    case '\n':
                        line++;

                        break;
                    case '!':
                        if(str.charAt(p+1)=='='){
                            writer.write("NEQ"+" "+"!=");
                            writer.newLine();
                            token0 = new Token("!=", "NEQ", line);
                            tokenList.add(token0);
                            p++;
                        } else{
                            writer.write("NOT"+" "+str.charAt(p));
                            writer.newLine();
                            token0 = new Token("!", "NOT", line);
                            tokenList.add(token0);
                        }
                        break;
                    case '|':
                        if(str.charAt(p+1)=='|'){
                            writer.write("OR"+" "+"||");
                            writer.newLine();
                            token0 = new Token("||", "OR", line);
                            tokenList.add(token0);
                            p++;
                        } else{
                            System.out.println("error of ||");
                        }
                        break;
                    case '&':
                        if(str.charAt(p+1)=='&'){
                            writer.write("AND"+" "+"&&");
                            writer.newLine();
                            token0 = new Token("&&", "AND", line);
                            tokenList.add(token0);
                            p++;
                        } else{
                            System.out.println("error of &&");
                        }
                        break;
                    case '+':
                        writer.write("PLUS"+" "+str.charAt(p));
                        writer.newLine();
                        token0 = new Token("+", "PLUS", line);
                        tokenList.add(token0);
                        break;
                    case '-':
                        writer.write("MINU"+" "+str.charAt(p));
                        writer.newLine();
                        token0 = new Token("-", "MINU", line);
                        tokenList.add(token0);
                        break;
                    case '*':
                        writer.write("MULT"+" "+str.charAt(p));
                        writer.newLine();
                        token0 = new Token("*", "MULT", line);
                        tokenList.add(token0);
                        break;
                    case '/':
                        writer.write("DIV"+" "+str.charAt(p));
                        writer.newLine();
                        token0 = new Token("/", "DIV", line);
                        tokenList.add(token0);
                        break;
                    case '%':
                        writer.write("MOD"+" "+str.charAt(p));
                        writer.newLine();
                        token0 = new Token("%", "MOD", line);
                        tokenList.add(token0);
                        break;
                    case '<':
                        if(str.charAt(p+1)=='='){
                            writer.write("LEQ"+" "+"<=");
                            writer.newLine();
                            token0 = new Token("<=", "LEQ", line);
                            tokenList.add(token0);
                            p++;
                        } else{
                            writer.write("LSS"+" "+str.charAt(p));
                            writer.newLine();
                            token0 = new Token("<", "LSS", line);
                            tokenList.add(token0);
                        }
                        break;
                    case '>':
                        if(str.charAt(p+1)=='='){
                            writer.write("GEQ"+" "+">=");
                            writer.newLine();
                            token0 = new Token(">=", "GEQ", line);
                            tokenList.add(token0);
                            p++;
                        } else{
                            writer.write("GRE"+" "+str.charAt(p));
                            writer.newLine();
                            token0 = new Token(">", "GRE", line);
                            tokenList.add(token0);
                        }
                        break;
                    case '=':
                        if(str.charAt(p+1)=='='){
                            writer.write("EQL"+" "+"==");
                            writer.newLine();
                            token0 = new Token("==", "EQL", line);
                            tokenList.add(token0);
                            p++;
                        } else{
                            writer.write("ASSIGN"+" "+str.charAt(p));
                            writer.newLine();
                            token0 = new Token("=", "ASSIGN", line);
                            tokenList.add(token0);
                        }
                        break;
                    case ';':
                        writer.write("SEMICN"+" "+str.charAt(p));
                        writer.newLine();
                        token0 = new Token(";", "SEMICN", line);
                        tokenList.add(token0);
                        break;
                    case ',':
                        writer.write("COMMA"+" "+str.charAt(p));
                        writer.newLine();
                        token0 = new Token(",", "COMMA", line);
                        tokenList.add(token0);
                        break;
                    case '(':
                        writer.write("LPARENT"+" "+str.charAt(p));
                        writer.newLine();
                        token0 = new Token("(", "LPARENT", line);
                        tokenList.add(token0);
                        break;
                    case ')':
                        writer.write("RPARENT"+" "+str.charAt(p));
                        writer.newLine();
                        token0 = new Token(")", "RPARENT", line);
                        tokenList.add(token0);
                        break;
                    case '[':
                        writer.write("LBRACK"+" "+str.charAt(p));
                        writer.newLine();
                        token0 = new Token("[", "LBRACK", line);
                        tokenList.add(token0);
                        break;
                    case ']':
                        writer.write("RBRACK"+" "+str.charAt(p));
                        writer.newLine();
                        token0 = new Token("]", "RBRACK", line);
                        tokenList.add(token0);
                        break;
                    case '{':
                        writer.write("LBRACE"+" "+str.charAt(p));
                        writer.newLine();
                        token0 = new Token("{", "LBRACE", line);
                        tokenList.add(token0);
                        break;
                    case '}':
                        writer.write("RBRACE"+" "+str.charAt(p));
                        writer.newLine();
                        token0 = new Token("}", "RBRACE", line);
                        tokenList.add(token0);
                        break;
                    case '"':
                        int p0=p;
                        p++;
                        while (str.charAt(p)!='"'){
                            p++;
                        }
                        writer.write("STRCON"+" "+str.substring(p0,p+1));
                        writer.newLine();
                        token0 = new Token(str.substring(p0,p+1), "STRCON", line);
                        tokenList.add(token0);
                        if(!isFormatStringValid(token0.getContent())){
                            error0 = new Error("a",line);
                            errorList.add(error0);
                        }
                        break;
                    default:
                        //如果当前字符是字母或下划线
                        if (Character.isLetter(str.charAt(p))||str.charAt(p)=='_') {
                            String ind=readIdentifier(str,p);
                            p=p+ind.length()-1;
                            if(getCode(ind)!=null){
                                writer.write(getCode(ind)+" "+ind);
                                writer.newLine(); // 写入换行符
                                token0 = new Token(ind, getCode(ind), line);
                                tokenList.add(token0);
                            }
                            else{
                                writer.write("IDENFR "+ind);
                                writer.newLine(); // 写入换行符
                                token0 = new Token(ind, "IDENFR", line);
                                tokenList.add(token0);
                            }
                        }
                        //如果是数字
                        else if(Character.isDigit(str.charAt(p))) {
                            String ind=readNumberString(str,p);
                            p=p+ind.length()-1;
                            writer.write("INTCON "+ind);
                            writer.newLine(); // 写入换行符
                            token0 = new Token(ind, "INTCON", line);
                            tokenList.add(token0);
                        }else{
                            System.out.println("error :"+str.charAt(p));
                        }
                }
                p++;
            }
            // 关闭文件流
            reader.close();
            writer.close();

        } catch (IOException e) {
            System.err.println("发生错误: " + e.getMessage());
        }
        parseCompUnit(0,0, root_compUnit);
        setLoop();
        //给main函数的返回值类型设为int
        tableList.get(tableList.size()-1).isInt = 1;
        /*
        String fileName = "output.txt";
        try {
            FileWriter fileWriter = new FileWriter(fileName, false); // 使用false参数表示覆盖写入
            for (Token item : tokenListPlus) {
                if(!("<BlockItem>".equals(item.getType()) || "<Decl>".equals(item.getType()) || "<BType>".equals(item.getType()))){
                    fileWriter.write(item + "\n");
                }
            }
            fileWriter.close();
            System.out.println("ArrayList的内容已成功写入文件 " + fileName);
        } catch (IOException e) {
            e.printStackTrace();
            System.err.println("写入文件时出现错误");
        }
        */
        errorHandle(root_compUnit);
        sortErrorList();
        String fileName = "error.txt";
        try {
            FileWriter fileWriter = new FileWriter(fileName, false); // 使用false参数表示覆盖写入
            for (Error item : errorList) {
                //if(!(item.getType()=="<BlockItem>"||item.getType()=="<Decl>"||item.getType()=="<BType>")){
                    fileWriter.write(item + "\n");
                //}
            }
            fileWriter.close();
            System.out.println("errorlist的内容已成功写入文件 " + fileName);
        } catch (IOException e) {
            e.printStackTrace();
            System.err.println("写入文件时出现错误");
        }

        printTable();
        //printTokenList(tokenListPlus);
        System.out.println("");
        //postOrderTraversal1(node);
        postOrderTraversalToFile(root_compUnit);

        produceMiddle(root_compUnit);

        fileName = "llvm_ir.txt";
        try {
            FileWriter fileWriter = new FileWriter(fileName, false); // 使用false参数表示覆盖写入
            for (Line item : lineList) {
                fileWriter.write(item + "\n");
            }
            fileWriter.close();
            System.out.println("lineList的内容已成功写入文件 " + fileName);
        } catch (IOException e) {
            e.printStackTrace();
            System.err.println("写入文件时出现错误");
        }
    }
    public static int parseTerminal(int p, int tableId, TreeNode node){
        node.line = tokenList.get(p).getLineNum();
        token0 = tokenList.get(p);
        tokenListPlus.add(token0);
        return p+1;
    }
    public static int parseCompUnit(int p, int tableId, TreeNode node){
        //解析所有Decl
        while(true){
            if(tokenList.get(p).getType()=="CONSTTK"){
                TreeNode child = new TreeNode(p,tableId,"<Decl>");
                node.addChild(child);
                p=parseDecl(p, tableId, child);
            }
            else if(tokenList.get(p).getType()=="INTTK"&&tokenList.get(p+1).getType()=="IDENFR"&&tokenList.get(p+2).getType()!="LPARENT"){
                TreeNode child = new TreeNode(p,tableId,"<Decl>");
                node.addChild(child);
                p=parseDecl(p, tableId, child);
            }
            else{
                break;
            }
        }
        //解析所有FuncDef
        while(true){
            if(tokenList.get(p).getType()=="VOIDTK"){
                TreeNode child = new TreeNode(p,tableId,"<FuncDef>");
                node.addChild(child);
                p=parseFuncDef(p, tableId,child);
            }
            else if(tokenList.get(p).getType()=="INTTK"&&tokenList.get(p+1).getType()=="IDENFR"&&tokenList.get(p+2).getType()=="LPARENT"){
                TreeNode child = new TreeNode(p,tableId,"<FuncDef>");
                node.addChild(child);
                p=parseFuncDef(p, tableId,child);
            }
            else{
                break;
            }
        }
        //现在该解析MainFuncDef了
        if(tokenList.get(p+1).getType()=="MAINTK"){
            TreeNode child = new TreeNode(p,tableId,"<MainFuncDef>");
            node.addChild(child);
            p=parseMainFuncDef(p, tableId, child);
        }
        else {
            System.out.println("error of CompUnit");
        }
        token0 = new Token("", "<CompUnit>",0);
        tokenListPlus.add(token0);
        return p;
    }
    public static int parseForStmt(int p, int tableId, TreeNode node){
        child = new TreeNode(p,tableId,"<LVal>");
        node.addChild(child);
        p= parseLVal(p, tableId, child);
        //解析=
        child = new TreeNode(p,tableId,tokenList.get(p).getType(),tokenList.get(p).getContent());
        node.addChild(child);
        p=parseTerminal(p, tableId, child);
        child = new TreeNode(p,tableId,tokenList.get(p).getType(),tokenList.get(p).getContent());
        node.addChild(child);
        p=parseExp(p, tableId, child);
        token0 = new Token("", "<ForStmt>",0);
        tokenListPlus.add(token0);
        return p;
    }
    public static int parsePrimaryExp(int p, int tableId, TreeNode node){
        if(tokenList.get(p).getType()=="LPARENT"){
            child = new TreeNode(p,tableId,tokenList.get(p).getType(),tokenList.get(p).getContent());
            node.addChild(child);
            p=parseTerminal(p, tableId, child);
            TreeNode child1 = new TreeNode(p,tableId,"<Exp>");
            node.addChild(child1);
            p=parseExp(p, tableId, child1);
            node.expType = child1.expType;
            child = new TreeNode(p,tableId,tokenList.get(p).getType(),tokenList.get(p).getContent());
            node.addChild(child);
            p=parseTerminal(p, tableId, child);
        }
        else if(Objects.equals(tokenList.get(p).getType(), "IDENFR")){
            child = new TreeNode(p,tableId,"<LVal>");
            node.addChild(child);
            p= parseLVal(p, tableId, child);
            //System.out.println("<LVal>"+child.expType);
            node.expType = node.children.get(0).expType;
            //...
            System.out.println(node+"   0o0o");
        }
        else if(tokenList.get(p).getType()=="INTCON"){
            node.expType = 0;
            child = new TreeNode(p,tableId,"<Number>");
            node.addChild(child);
            p=parseNumber(p, tableId, child);
        }
        token0 = new Token("", "<PrimaryExp>",0);
        tokenListPlus.add(token0);
        return p;
    }
    public static int parseCond(int p, int tableId, TreeNode node){
        child = new TreeNode(p,tableId,"<LOrExp>");
        node.addChild(child);
        p=parseLOrExp(p, tableId, child);
        token0 = new Token("", "<Cond>",0);
        tokenListPlus.add(token0);
        return p;
    }

    public static int parseLOrExp(int p, int tableId, TreeNode node){
        child = new TreeNode(p,tableId,"<LAndExp>");
        node.addChild(child);
        p=parseLAndExp(p, tableId, child);

        while(tokenList.get(p).getType()=="OR"){
            TreeNode last=node.children.get(node.children.size() - 1);
            int size = node.children.size();
            node.children.remove(size-1);
            TreeNode newNode =new TreeNode(last.p, tableId,"<LOrExp>");
            newNode.children.add(last);
            node.children.add(newNode);

            token0 = new Token("", "<LOrExp>",0);
            tokenListPlus.add(token0);

            child = new TreeNode(p,tableId,tokenList.get(p).getType(),tokenList.get(p).getContent());
            node.addChild(child);
            p=parseTerminal(p, tableId, child);

            child = new TreeNode(p,tableId,"<LAndExp>");
            node.addChild(child);
            p=parseLAndExp(p, tableId, child);
        }
        token0 = new Token("", "<LOrExp>",0);
        tokenListPlus.add(token0);
        return p;
    }
    public static int parseLAndExp(int p, int tableId, TreeNode node){
        child = new TreeNode(p,tableId,"<EqExp>");
        node.addChild(child);
        p=parseEqExp(p, tableId, child);
        while(tokenList.get(p).getType()=="AND"){
            TreeNode last=node.children.get(node.children.size() - 1);
            int size = node.children.size();
            node.children.remove(size-1);
            TreeNode newNode =new TreeNode(last.p, tableId,"<LAndExp>");
            newNode.children.add(last);
            node.children.add(newNode);

            token0 = new Token("", "<LAndExp>",0);
            tokenListPlus.add(token0);
            child = new TreeNode(p,tableId,tokenList.get(p).getType(),tokenList.get(p).getContent());
            node.addChild(child);
            p=parseTerminal(p, tableId, child);
            child = new TreeNode(p,tableId,"<EqExp>");
            node.addChild(child);
            p=parseEqExp(p, tableId, child);
        }
        token0 = new Token("", "<LAndExp>",0);
        tokenListPlus.add(token0);
        return p;
    }
    public static int parseEqExp(int p, int tableId, TreeNode node){
        child = new TreeNode(p,tableId,"<RelExp>");
        node.addChild(child);
        p=parseRelExp(p, tableId, child);
        while(tokenList.get(p).getType()=="EQL"||tokenList.get(p).getType()=="NEQ"){
            TreeNode last=node.children.get(node.children.size() - 1);
            int size = node.children.size();
            node.children.remove(size-1);
            TreeNode newNode =new TreeNode(last.p, tableId,"<EqExp>");
            newNode.children.add(last);
            node.children.add(newNode);

            token0 = new Token("", "<EqExp>",0);
            tokenListPlus.add(token0);
            child = new TreeNode(p,tableId,tokenList.get(p).getType(),tokenList.get(p).getContent());
            node.addChild(child);
            p=parseTerminal(p, tableId, child);
            child = new TreeNode(p,tableId,"<RelExp>");
            node.addChild(child);
            p=parseRelExp(p, tableId, child);
        }
        token0 = new Token("", "<EqExp>",0);
        tokenListPlus.add(token0);
        return p;
    }
    public static int parseRelExp(int p, int tableId, TreeNode node){
        child = new TreeNode(p,tableId,"<AddExp>");
        node.addChild(child);
        p=parseAddExp(p, tableId, child);
        while(tokenList.get(p).getType()=="LSS"||tokenList.get(p).getType()=="GRE"||tokenList.get(p).getType()=="LEQ"||tokenList.get(p).getType()=="GEQ"){
            TreeNode last=node.children.get(node.children.size() - 1);
            int size = node.children.size();
            node.children.remove(size-1);
            TreeNode newNode =new TreeNode(last.p, tableId,"<RelExp>");
            newNode.children.add(last);
            node.children.add(newNode);
            token0 = new Token("", "<RelExp>",0);
            tokenListPlus.add(token0);

            child = new TreeNode(p,tableId,tokenList.get(p).getType(),tokenList.get(p).getContent());
            node.addChild(child);
            p=parseTerminal(p, tableId, child);
            child = new TreeNode(p,tableId,"<AddExp>");
            node.addChild(child);
            p=parseAddExp(p, tableId, child);
        }
        token0 = new Token("", "<RelExp>",0);
        tokenListPlus.add(token0);
        return p;
    }

    public static int parseConstExp(int p, int tableId, TreeNode node){
        child = new TreeNode(p,tableId,"<AddExp>");
        node.addChild(child);
        p=parseAddExp(p, tableId, child);
        token0 = new Token("", "<ConstExp>",0);
        tokenListPlus.add(token0);
        return p;
    }
    public static int parseAddExp(int p, int tableId, TreeNode node){
        TreeNode child = new TreeNode(p,tableId,"<MulExp>");
        node.addChild(child);
        p=parseMulExp(p, tableId, child);
        node.expType = child.expType;
        while(tokenList.get(p).getType()=="PLUS"||tokenList.get(p).getType()=="MINU"){
            token0 = new Token("", "<AddExp>",0);
            tokenListPlus.add(token0);
            child = new TreeNode(p,tableId,tokenList.get(p).getType(),tokenList.get(p).getContent());
            node.addChild(child);
            p=parseTerminal(p, tableId, child);
            child = new TreeNode(p,tableId,"<MulExp>");
            node.addChild(child);
            p=parseMulExp(p, tableId, child);
        }
        token0 = new Token("", "<AddExp>",0);
        tokenListPlus.add(token0);
        return p;
    }
    public static int parseMulExp(int p, int tableId, TreeNode node){
        TreeNode child = new TreeNode(p,tableId,"<UnaryExp>");
        node.addChild(child);
        p=parseUnaryExp(p, tableId, child);
        node.expType = child.expType;
        while(tokenList.get(p).getType()=="MULT"||tokenList.get(p).getType()=="DIV"||tokenList.get(p).getType()=="MOD"){
            token0 = new Token("", "<MulExp>",0);
            tokenListPlus.add(token0);
            token0 = new Token("", "<MulExp>",0);
            tokenListPlus.add(token0);
            child = new TreeNode(p,tableId,tokenList.get(p).getType(),tokenList.get(p).getContent());
            node.addChild(child);
            p=parseTerminal(p, tableId, child);

            child = new TreeNode(p,tableId,"<UnaryExp>");
            node.addChild(child);
            p=parseUnaryExp(p, tableId, child);
        }
        token0 = new Token("", "<MulExp>",0);
        tokenListPlus.add(token0);
        return p;
    }
    public static int parseUnaryExp(int p, int tableId, TreeNode node){
        if(tokenList.get(p).getType()=="IDENFR"&&tokenList.get(p+1).getType()=="LPARENT"){
            //parse一个Ident
            //node.expType =
            int success = 0;
            int expType = -2;
            int tableId0 = tableId;
            while(tableId0>=0){
                Table t0 = tableList.get(tableId0);
                if(t0.symbolList.containsKey(tokenList.get(p).getContent())){
                    success = 1;
                    expType = t0.symbolList.get(tokenList.get(p).getContent()).type;
                    break;
                }
                else{
                    tableId0 = t0.fatherId;
                }
            }
            node.expType = expType;
            child = new TreeNode(p,tableId,tokenList.get(p).getType(),tokenList.get(p).getContent());
            node.addChild(child);
            p=parseTerminal(p, tableId, child);
            //解析(
            child = new TreeNode(p,tableId,tokenList.get(p).getType(),tokenList.get(p).getContent());
            node.addChild(child);
            p=parseTerminal(p, tableId, child);
            if(Objects.equals(tokenList.get(p).getType(), "RPARENT")){
                //解析)
                child = new TreeNode(p,tableId,tokenList.get(p).getType(),tokenList.get(p).getContent());
                node.addChild(child);
                p=parseTerminal(p, tableId, child);
            }
            else{
                child = new TreeNode(p,tableId,"<FuncRParams>");
                node.addChild(child);
                p=parseFuncRParams(p, tableId, child);
                /*
                //解析)
                child = new TreeNode(p,tableId,tokenList.get(p).getType(),tokenList.get(p).getContent());
                node.addChild(child);
                p=parseTerminal(p, tableId, child);
                */
                if(tokenList.get(p).getType().equals("RPARENT")) {
                    child = new TreeNode(p,tableId,"RPARENT",")");
                    node.addChild(child);
                    p=parseTerminal(p, tableId, child);//]
                }
                else {
                    child = new TreeNode(p,tableId,"RPARENT",")");
                    node.addChild(child);
                    error0 = new Error("j",tokenList.get(p).getLineNum());
                    errorList.add(error0);
                }
            }
        }
        else if(tokenList.get(p).getType()=="PLUS"||tokenList.get(p).getType()=="MINU"||tokenList.get(p).getType()=="NOT"){
            child = new TreeNode(p,tableId,"<UnaryOp>");
            node.addChild(child);
            p=parseUnaryOp(p, tableId, child);
            child = new TreeNode(p,tableId,"<UnaryExp>");
            node.addChild(child);
            p=parseUnaryExp(p, tableId, child);
            node.expType = child.expType;
        }
        else{
            TreeNode child = new TreeNode(p,tableId,"<PrimaryExp>");
            node.addChild(child);
            p=parsePrimaryExp(p, tableId, child);
            node.expType = child.expType;
        }
        token0 = new Token("", "<UnaryExp>",0);
        tokenListPlus.add(token0);
        return p;
    }
    public static int parseExp(int p, int tableId, TreeNode node){
        TreeNode child = new TreeNode(p,tableId,"<AddExp>");
        node.addChild(child);
        p=parseAddExp(p, tableId, child);
        node.expType = child.expType;
        token0 = new Token("", "<Exp>",0);
        tokenListPlus.add(token0);
        return p;
    }
    public static int parseFuncRParams(int p, int tableId, TreeNode node){
        TreeNode child = new TreeNode(p,tableId,"<Exp>");
        node.addChild(child);
        p=parseExp(p, tableId, child);
        node.FuncRParamsType.add(child.expType);
        while(tokenList.get(p).getType()=="COMMA"){
            child = new TreeNode(p,tableId,tokenList.get(p).getType(),tokenList.get(p).getContent());
            node.addChild(child);
            p=parseTerminal(p, tableId, child);
            child = new TreeNode(p,tableId,"<Exp>");
            node.addChild(child);
            p=parseExp(p, tableId, child);
            node.FuncRParamsType.add(child.expType);
        }
        //System.out.println("qeidqdjqwiod"+node.FuncRParamsType);
        token0 = new Token("", "<FuncRParams>",0);
        tokenListPlus.add(token0);
        return p;
    }
    public static int parseLVal(int p, int tableId, TreeNode node){
        int expType = -2;
        while(tableId>=0){
            Table t0 = tableList.get(tableId);
            if(t0.symbolList.containsKey(tokenList.get(p).getContent())){
                expType = t0.symbolList.get(tokenList.get(p).getContent()).type;
                break;
            }
            else{
                tableId = t0.fatherId;
            }
        }
        child = new TreeNode(p,tableId,tokenList.get(p).getType(),tokenList.get(p).getContent());
        node.addChild(child);
        p=parseTerminal(p, tableId, child);

        while(tokenList.get(p).getType()=="LBRACK"){
            expType--;
            child = new TreeNode(p,tableId,tokenList.get(p).getType(),tokenList.get(p).getContent());
            node.addChild(child);
            p=parseTerminal(p, tableId, child);

            child = new TreeNode(p,tableId,"<Exp>");
            node.addChild(child);
            p=parseExp(p, tableId, child);
            /*
            child = new TreeNode(p,tableId,tokenList.get(p).getType(),tokenList.get(p).getContent());
            node.addChild(child);
            //要求这里必须是]
            p=parseTerminal(p, tableId, child);
            */
            if(tokenList.get(p).getType().equals("RBRACK")) {
                child = new TreeNode(p,tableId,"RBRACK",tokenList.get(p).getContent());
                node.addChild(child);
                p=parseTerminal(p, tableId, child);//]
            }
            else {
                child = new TreeNode(p,tableId,"RBRACK","]");
                node.addChild(child);
                error0 = new Error("k",tokenList.get(p).getLineNum());
                errorList.add(error0);
                //System.out.println("<ConstExp> "+p);
                //p--;
            }
        }
        node.expType = expType;
        System.out.println(node.toString()+"  ede232");
        token0 = new Token("", "<LVal>",0);
        tokenListPlus.add(token0);
        return p;
    }
    public static int parseUnaryOp(int p, int tableId, TreeNode node){
        if(tokenList.get(p).getType()=="PLUS"||tokenList.get(p).getType()=="MINU"||tokenList.get(p).getType()=="NOT"){
            child = new TreeNode(p,tableId,tokenList.get(p).getType(),tokenList.get(p).getContent());
            node.addChild(child);
            p=parseTerminal(p, tableId, child);
            token0 = new Token("", "<UnaryOp>",0);
            tokenListPlus.add(token0);
        }
        else {
            System.out.println("error of parseUnaryOp");
        }
        return p;
    }
    public static int parseNumber(int p, int tableId, TreeNode node){
        child = new TreeNode(p,tableId,tokenList.get(p).getType(),tokenList.get(p).getContent());
        node.addChild(child);
        p=parseTerminal(p, tableId, child);
        token0 = new Token("", "<Number>",0);
        tokenListPlus.add(token0);
        return p;
    }
    public static int parseBType(int p, int tableId, TreeNode node){
        if(tokenList.get(p).getType()=="INTTK"){
            child = new TreeNode(p,tableId,"INTTK","int");
            node.addChild(child);
            p=parseTerminal(p, tableId, child);//int
            token0 = new Token("", "<BType>",0);
            tokenListPlus.add(token0);
        }
        else {
            System.out.println("error of parseBType");
        }
        return p;
    }
    public static int parseInitVal(int p, int tableId, TreeNode node){
        if(tokenList.get(p).getType()=="LBRACE"){
            if(tokenList.get(p+1).getType()=="RBRACE"){
                child = new TreeNode(p,tableId,"LBRACE",tokenList.get(p).getContent());
                node.addChild(child);
                p=parseTerminal(p, tableId, child);
                child = new TreeNode(p,tableId,"RBRACE",tokenList.get(p).getContent());
                node.addChild(child);
                p=parseTerminal(p, tableId, child);
            }
            else{
                child = new TreeNode(p,tableId,"LBRACE",tokenList.get(p).getContent());
                node.addChild(child);
                p=parseTerminal(p, tableId, child);

                child = new TreeNode(p,tableId,"<InitVal>");
                node.addChild(child);
                p=parseInitVal(p, tableId, child);
                while(tokenList.get(p).getType()=="COMMA"){
                    child = new TreeNode(p,tableId,"COMMA",tokenList.get(p).getContent());
                    node.addChild(child);
                    p=parseTerminal(p, tableId, child);
                    child = new TreeNode(p,tableId,"<InitVal>");
                    node.addChild(child);
                    p=parseInitVal(p, tableId, child);
                }
                child = new TreeNode(p,tableId,"RBRACE",tokenList.get(p).getContent());
                node.addChild(child);
                p=parseTerminal(p, tableId, child);
            }
        }
        else {
            child = new TreeNode(p,tableId,"<Exp>");
            node.addChild(child);
            p=parseExp(p, tableId, child);
        }
        token0 = new Token("", "<InitVal>",0);
        tokenListPlus.add(token0);
        return p;
    }
    public static int parseConstInitVal(int p, int tableId, TreeNode node){
        if(tokenList.get(p).getType()=="LBRACE"){
            if(tokenList.get(p+1).getType()=="RBRACE"){
                child = new TreeNode(p,tableId,"LBRACE","{");
                node.addChild(child);
                p=parseTerminal(p, tableId, child);

                child = new TreeNode(p,tableId,"RBRACE","}");
                node.addChild(child);
                p=parseTerminal(p, tableId, child);
            }
            else{
                child = new TreeNode(p,tableId,"LBRACE","{");
                node.addChild(child);
                p=parseTerminal(p, tableId, child);

                child = new TreeNode(p,tableId,"<ConstInitVal>");
                node.addChild(child);
                p=parseConstInitVal(p, tableId, child);
                while(tokenList.get(p).getType()=="COMMA"){
                    child = new TreeNode(p,tableId,"COMMA",",");
                    node.addChild(child);
                    p=parseTerminal(p, tableId, child);

                    child = new TreeNode(p,tableId,"<ConstInitVal>");
                    node.addChild(child);
                    p=parseConstInitVal(p, tableId, child);
                }
                child = new TreeNode(p,tableId,"RBRACE","}");
                node.addChild(child);
                p=parseTerminal(p, tableId, child);//}
            }
        }
        else {
            child = new TreeNode(p,tableId,"<ConstExp>");
            node.addChild(child);
            p=parseConstExp(p, tableId, child);
        }
        token0 = new Token("", "<ConstInitVal>",0);
        tokenListPlus.add(token0);
        return p;
    }
    public static int parseMainFuncDef(int p, int tableId, TreeNode node){
        child = new TreeNode(p,tableId,"INTTK","int");
        node.addChild(child);
        p=parseTerminal(p, tableId, child);//int

        child = new TreeNode(p,tableId,"MAINTK","main");
        node.addChild(child);
        p=parseTerminal(p, tableId, child);//main

        child = new TreeNode(p,tableId,"LPARENT","(");
        node.addChild(child);
        p=parseTerminal(p, tableId, child);//(

        child = new TreeNode(p,tableId,"RPARENT",")");
        node.addChild(child);
        p=parseTerminal(p, tableId, child);

        child = new TreeNode(p,tableId,"<Block>");
        node.addChild(child);
        p=parseBlock(p, tableId, child);
        token0 = new Token("", "<MainFuncDef>",0);
        tokenListPlus.add(token0);
        return p;
    }
    public static int parseFuncType(int p, int tableId, TreeNode node){
        child = new TreeNode(p,tableId,tokenList.get(p).getType(),tokenList.get(p).getContent());
        node.addChild(child);
        p=parseTerminal(p, tableId, child);
        token0 = new Token("", "<FuncType>",0);
        tokenListPlus.add(token0);
        return p;
    }
    public static int parseBlock(int p, int tableId, TreeNode node){
        ArrayList<Integer> FuncFParamsList = node.FuncFParams;
        ArrayList<String> FuncFParamsNameList = node.FuncFParamsName;
        //这两行建语法树后作废
        //node.FuncFParams = null;
        //node.FuncFParamsName = null;
        child = new TreeNode(p,tableId,"LBRACE","{");
        node.addChild(child);
        p=parseTerminal(p, tableId, child);//{

        //新建一个表并为其分配id，并设置好父id(如果这个表是函数定义对应的那个表，还要添加FuncDef传来的形参)
        int id  = tableList.size();
        node.tableId = id;
        Table table0 = new Table(id,tableId);
        if(FuncFParamsList!=null){
            table0.isFunction = 1;
            table0.isInt = node.isInt;
            for(int i=0;i<FuncFParamsList.size();i++){
                //table0.symbolList.put(FuncFParamsList.get(i));
                Symbol s =new Symbol(id,FuncFParamsNameList.get(i),FuncFParamsList.get(i),0);
                table0.symbolList.put(FuncFParamsNameList.get(i),s);
            }
        }
        tableList.add(table0);
        while(tokenList.get(p).getType()!="RBRACE"){
            System.out.print(tokenList.get(p).getContent()+" ");
            System.out.println(tokenList.get(p+1).getContent());

            child = new TreeNode(p,id,"<BlockItem>");
            node.addChild(child);
            p=parseBlockItem(p, id, child);
        }

        child = new TreeNode(p,tableId,"RBRACE","}");
        node.addChild(child);
        p=parseTerminal(p, tableId, child);//}
        token0 = new Token("", "<Block>",0);
        tokenListPlus.add(token0);
        return p;
    }
    public static int parseBlockItem(int p, int tableId, TreeNode node){
        if(tokenList.get(p).getType()=="CONSTTK"||tokenList.get(p).getType()=="INTTK"){
            child = new TreeNode(p,tableId,"<Decl>");
            node.addChild(child);
            p=parseDecl(p, tableId, child);
        }
        else {
            child = new TreeNode(p,tableId,"<Stmt>");
            node.addChild(child);
            p=parseStmt(p, tableId, child);
        }
        token0 = new Token("", "<BlockItem>",0);
        tokenListPlus.add(token0);
        return p;
    }
    public static int parseStmt(int p, int tableId, TreeNode node){
        if(tokenList.get(p).getType()=="PRINTFTK"){
            int line = tokenList.get(p).getLineNum();
            child = new TreeNode(p,tableId,tokenList.get(p).getType(),tokenList.get(p).getContent());
            node.addChild(child);
            p=parseTerminal(p, tableId, child);//printf
            child = new TreeNode(p,tableId,tokenList.get(p).getType(),tokenList.get(p).getContent());
            node.addChild(child);
            p=parseTerminal(p, tableId, child);//(
            //为了检测printf中格式字符与表达式个数是否匹配，须得知FormatString里“%d”的数量
            String formatString =tokenList.get(p).getContent();
            int numOfPer = 0;
            int numOfComma = 0;
            for(int i=0; i<formatString.length(); i++){
                if((i!=formatString.length()-1)&&(formatString.charAt(i)=='%'&&formatString.charAt(i+1)=='d')){
                    numOfPer++;
                }
            }
            child = new TreeNode(p,tableId,tokenList.get(p).getType(),tokenList.get(p).getContent());
            node.addChild(child);
            p=parseTerminal(p, tableId, child);//FormatString
            while(tokenList.get(p).getType()=="COMMA"){
                child = new TreeNode(p,tableId,tokenList.get(p).getType(),tokenList.get(p).getContent());
                node.addChild(child);
                p=parseTerminal(p, tableId, child);
                child = new TreeNode(p,tableId,"<Exp>");
                node.addChild(child);
                p=parseExp(p, tableId, child);
                numOfComma++;
            }
            if(numOfPer!=numOfComma){
                error0 = new Error("l",line);
                errorList.add(error0);
            }
            /*
            child = new TreeNode(p,tableId,tokenList.get(p).getType(),tokenList.get(p).getContent());
            node.addChild(child);
            p=parseTerminal(p, tableId, node);
            */
            if(tokenList.get(p).getType().equals("RPARENT")) {
                child = new TreeNode(p,tableId,"RPARENT",")");
                node.addChild(child);
                p=parseTerminal(p, tableId, child);//)
            }
            else {
                child = new TreeNode(p,tableId,"RPARENT",")");
                node.addChild(child);
                error0 = new Error("j",tokenList.get(p).getLineNum());
                errorList.add(error0);
            }
            if(tokenList.get(p).getType()!="SEMICN"){
                line = tokenList.get(p-1).getLineNum();
                error0 = new Error("i",line);
                errorList.add(error0);
                //p++;
            }
            else {
                child = new TreeNode(p,tableId,tokenList.get(p).getType(),tokenList.get(p).getContent());
                node.addChild(child);
                p=parseTerminal(p, tableId, child);
            }
        }
        else if(tokenList.get(p).getType()=="BREAKTK"){
            child = new TreeNode(p,tableId,tokenList.get(p).getType(),tokenList.get(p).getContent());
            node.addChild(child);
            p=parseTerminal(p, tableId, child);
            if(tokenList.get(p).getType()!="SEMICN"){
                int line = tokenList.get(p-1).getLineNum();
                error0 = new Error("i",line);
                errorList.add(error0);
                p++;
            }
            else {
                child = new TreeNode(p,tableId,tokenList.get(p).getType(),tokenList.get(p).getContent());
                node.addChild(child);
                p=parseTerminal(p, tableId, child);
            }
        }
        else if(tokenList.get(p).getType()=="CONTINUETK"){
            child = new TreeNode(p,tableId,tokenList.get(p).getType(),tokenList.get(p).getContent());
            node.addChild(child);
            p=parseTerminal(p, tableId, child);
            if(tokenList.get(p).getType()!="SEMICN"){
                int line = tokenList.get(p-1).getLineNum();
                error0 = new Error("i",line);
                errorList.add(error0);
                p++;
            }
            else {
                child = new TreeNode(p,tableId,tokenList.get(p).getType(),tokenList.get(p).getContent());
                node.addChild(child);
                p=parseTerminal(p, tableId, child);
            }
        }
        else if(tokenList.get(p).getType()=="IFTK"){
            child = new TreeNode(p,tableId,tokenList.get(p).getType(),tokenList.get(p).getContent());
            node.addChild(child);
            p=parseTerminal(p, tableId, child);//if
            child = new TreeNode(p,tableId,tokenList.get(p).getType(),tokenList.get(p).getContent());
            node.addChild(child);
            p=parseTerminal(p, tableId, child);//(
            child = new TreeNode(p,tableId,"<Cond>");
            node.addChild(child);
            p=parseCond(p, tableId, child);
            if(tokenList.get(p).getType().equals("RPARENT")) {
                child = new TreeNode(p,tableId,"RPARENT",")");
                node.addChild(child);
                p=parseTerminal(p, tableId, child);//)
            }
            else {
                child = new TreeNode(p,tableId,"RPARENT",")");
                node.addChild(child);
                error0 = new Error("j",tokenList.get(p).getLineNum());
                errorList.add(error0);
            }
            /*
            child = new TreeNode(p,tableId,tokenList.get(p).getType(),tokenList.get(p).getContent());
            node.addChild(child);
            p=parseTerminal(p, tableId, child);//(
            */
            child = new TreeNode(p,tableId,"<Stmt>");
            node.addChild(child);
            p=parseStmt(p, tableId, child);
            if(tokenList.get(p).getType()=="ELSETK"){
                child = new TreeNode(p,tableId,tokenList.get(p).getType(),tokenList.get(p).getContent());
                node.addChild(child);
                p=parseTerminal(p, tableId, child);
                child = new TreeNode(p,tableId,"<Stmt>");
                node.addChild(child);
                p=parseStmt(p, tableId, child);
            }
        }
        else if(tokenList.get(p).getType()=="FORTK"){
            child = new TreeNode(p,tableId,tokenList.get(p).getType(),tokenList.get(p).getContent());
            node.addChild(child);
            p=parseTerminal(p, tableId, child);//for
            child = new TreeNode(p,tableId,tokenList.get(p).getType(),tokenList.get(p).getContent());
            node.addChild(child);
            p=parseTerminal(p, tableId, child);//(
            if(tokenList.get(p).getType()=="SEMICN"){
                child = new TreeNode(p,tableId,tokenList.get(p).getType(),tokenList.get(p).getContent());
                node.addChild(child);
                p=parseTerminal(p, tableId, child);
            }
            else {
                child = new TreeNode(p,tableId,"<ForStmt");
                node.addChild(child);
                p=parseForStmt(p, tableId, child);
                child = new TreeNode(p,tableId,tokenList.get(p).getType(),tokenList.get(p).getContent());
                node.addChild(child);
                p=parseTerminal(p, tableId, child);
            }
            if(tokenList.get(p).getType()=="SEMICN"){
                child = new TreeNode(p,tableId,tokenList.get(p).getType(),tokenList.get(p).getContent());
                node.addChild(child);
                p=parseTerminal(p, tableId, child);
            }
            else {
                child = new TreeNode(p,tableId,"<Cond>");
                node.addChild(child);
                p=parseCond(p, tableId, child);
                child = new TreeNode(p,tableId,tokenList.get(p).getType(),tokenList.get(p).getContent());
                node.addChild(child);
                p=parseTerminal(p, tableId, child);
            }
            if(tokenList.get(p).getType()=="RPARENT"){
                child = new TreeNode(p,tableId,tokenList.get(p).getType(),tokenList.get(p).getContent());
                node.addChild(child);
                p=parseTerminal(p, tableId, child);
            }
            else {
                child = new TreeNode(p,tableId,"<ForStmt>");
                node.addChild(child);
                p=parseForStmt(p, tableId, child);
                child = new TreeNode(p,tableId,tokenList.get(p).getType(),tokenList.get(p).getContent());
                node.addChild(child);
                p=parseTerminal(p, tableId, child);
            }
            tokenList.get(p).loopStart=1;
            child = new TreeNode(p,tableId,"<Stmt>");
            node.addChild(child);
            p=parseStmt(p, tableId, child);
            tokenList.get(p-1).loopEnd=1;
        }
        else if(tokenList.get(p).getType()=="RETURNTK"){
            child = new TreeNode(p,tableId,tokenList.get(p).getType(),tokenList.get(p).getContent());
            node.addChild(child);
            p=parseTerminal(p, tableId, child);//return
            if(Objects.equals(tokenList.get(p).getType(), "SEMICN")){
                child = new TreeNode(p,tableId,tokenList.get(p).getType(),tokenList.get(p).getContent());
                node.addChild(child);
                p=parseTerminal(p, tableId, child);
            }
            //这个FIRST集表明return后面还有一个Exp
            else if(tokenList.get(p).getType()=="LPARENT"||tokenList.get(p).getType()=="PLUS"||tokenList.get(p).getType()=="MINU"||tokenList.get(p).getType()=="NOT"||tokenList.get(p).getType()=="IDENFR"|| Objects.equals(tokenList.get(p).getType(), "INTCON")){
                child = new TreeNode(p,tableId,"<Exp>");
                node.addChild(child);
                p=parseExp(p, tableId, child);
                if(Objects.equals(tokenList.get(p).getType(), "SEMICN")){
                    System.out.println("sudqiwejoqiwd");
                    child = new TreeNode(p,tableId,tokenList.get(p).getType(),tokenList.get(p).getContent());
                    node.addChild(child);
                    p=parseTerminal(p, tableId, child);
                }
                else {
                    int line = tokenList.get(p-1).getLineNum();
                    error0 = new Error("i",line);
                    errorList.add(error0);
                    child = new TreeNode(p,tableId,"SEMICN",";");
                    node.addChild(child);
                }
            }
            else{//只有一个return，且缺分号
                int line = tokenList.get(p-1).getLineNum();
                error0 = new Error("i",line);
                errorList.add(error0);
                child = new TreeNode(p,tableId,"SEMICN",";");
                node.addChild(child);
                //p=parseTerminal(p, tableId, child);
                //p++;
            }
        }
        else if(tokenList.get(p).getType()=="LBRACE"){
            child = new TreeNode(p,tableId,"<Block>");
            node.addChild(child);
            p=parseBlock(p, tableId, child);
        }
        else if(tokenList.get(p).getType()=="LPARENT"||tokenList.get(p).getType()=="INTCON"||tokenList.get(p).getType()=="SEMICN"){
            if(tokenList.get(p).getType()=="SEMICN"){
                child = new TreeNode(p,tableId,tokenList.get(p).getType(),tokenList.get(p).getContent());
                node.addChild(child);
                p=parseTerminal(p, tableId, child);
            }
            else {
                child = new TreeNode(p,tableId,"<Exp>");
                node.addChild(child);
                p=parseExp(p, tableId, child);
                if(tokenList.get(p).getType()!="SEMICN"){
                    int line = tokenList.get(p-1).getLineNum();
                    error0 = new Error("i",line);
                    errorList.add(error0);
                }
                else {
                    child = new TreeNode(p,tableId,tokenList.get(p).getType(),tokenList.get(p).getContent());
                    node.addChild(child);
                    p=parseTerminal(p, tableId, child);
                }
            }
        }
        /*  else if(tokenList.get(p).getType()=="IDENFR"){
            int p0 = p;
            int flag=0;
            if(tokenList.get(p+1).getType()=="LPARENT"){
                flag = 0;
                p=parseExp(p);
                if(tokenList.get(p).getType()!="SEMICN"){
                    int line = tokenList.get(p-1).getLineNum();
                    error0 = new Error("i",line);
                    errorList.add(error0);
                }
                else {
                    p=parseTerminal(p);
                }
            }
            else {
                p=parseLval(p);
                if(tokenList.get(p+1).getType()=="ASSIGN"){
                    p=parseTerminal(p);//=
                    p=parseExp(p);
                }
                else if(tokenList.get(p+1).getType()=="SEMICN"){
                    p=parseTerminal(p);
                }
            }
            if(flag==0){//没等号
                p=parseExp(p);
                if(tokenList.get(p).getType()!="SEMICN"){
                    int line = tokenList.get(p-1).getLineNum();
                    error0 = new Error("i",line);
                    errorList.add(error0);
                }
                else {
                    p=parseTerminal(p);
                }
            }
            else{
                p=parseLval(p);
                p=parseTerminal(p);
                if(tokenList.get(p).getType()=="GETINTTK"){
                    p=parseTerminal(p);
                    p=parseTerminal(p);
                    p=parseTerminal(p);
                    if(tokenList.get(p).getType()!="SEMICN"){
                        int line = tokenList.get(p-1).getLineNum();
                        error0 = new Error("i",line);
                        errorList.add(error0);
                    }
                    else {
                        p=parseTerminal(p);
                    }
                }
                else{
                    p=parseExp(p);
                    if(tokenList.get(p).getType()!="SEMICN"){
                        int line = tokenList.get(p-1).getLineNum();
                        error0 = new Error("i",line);
                        errorList.add(error0);
                    }
                    else {
                        p=parseTerminal(p);
                    }
                }
            }
        }   */
        else if(tokenList.get(p).getType()=="IDENFR"){
            int p0 = p;
            int flag=0;
            while(tokenList.get(p0).getContent()!=";"){
                if(tokenList.get(p0).getContent()=="="){
                    flag=1;
                }
                p0++;
            }
            if(flag==0){
                child = new TreeNode(p,tableId,"<Exp>");
                node.addChild(child);
                p=parseExp(p, tableId, child);
                child = new TreeNode(p,tableId,tokenList.get(p).getType(),tokenList.get(p).getContent());
                node.addChild(child);
                p=parseTerminal(p, tableId, child);
            }
            else{
                child = new TreeNode(p,tableId,"<LVal>");
                node.addChild(child);
                p= parseLVal(p, tableId, child);
                child = new TreeNode(p,tableId,tokenList.get(p).getType(),tokenList.get(p).getContent());
                node.addChild(child);
                p=parseTerminal(p, tableId, child);
                if(tokenList.get(p).getType()=="GETINTTK"){
                    child = new TreeNode(p,tableId,tokenList.get(p).getType(),tokenList.get(p).getContent());
                    node.addChild(child);
                    p=parseTerminal(p, tableId, child);//getint
                    child = new TreeNode(p,tableId,tokenList.get(p).getType(),tokenList.get(p).getContent());
                    node.addChild(child);
                    p=parseTerminal(p, tableId, child);//(
                    /*
                    child = new TreeNode(p,tableId,tokenList.get(p).getType(),tokenList.get(p).getContent());
                    node.addChild(child);
                    p=parseTerminal(p, tableId, child);//)
                    */
                    if(tokenList.get(p).getType().equals("RPARENT")) {
                        child = new TreeNode(p,tableId,"RPARENT",")");
                        node.addChild(child);
                        p=parseTerminal(p, tableId, child);//)
                    }
                    else {
                        child = new TreeNode(p,tableId,"RPARENT",")");
                        node.addChild(child);
                        error0 = new Error("j",tokenList.get(p).getLineNum());
                        errorList.add(error0);
                    }
                    child = new TreeNode(p,tableId,tokenList.get(p).getType(),tokenList.get(p).getContent());
                    node.addChild(child);
                    p=parseTerminal(p, tableId, child);//;
                }
                else{
                    child = new TreeNode(p,tableId,"<Exp>");
                    node.addChild(child);
                    p=parseExp(p, tableId, child);
                    child = new TreeNode(p,tableId,tokenList.get(p).getType(),tokenList.get(p).getContent());
                    node.addChild(child);
                    p=parseTerminal(p, tableId, child);
                }
            }
        }
        else if(tokenList.get(p).getType()=="PLUS"||tokenList.get(p).getType()=="MINU"||tokenList.get(p).getType()=="NOT"){
            child = new TreeNode(p,tableId,"<Exp>");
            node.addChild(child);
            p=parseExp(p, tableId, child);
            if(tokenList.get(p).getType()!="SEMICN"){
                int line = tokenList.get(p-1).getLineNum();
                error0 = new Error("i",line);
                errorList.add(error0);
            }
            else {
                child = new TreeNode(p,tableId,tokenList.get(p).getType(),tokenList.get(p).getContent());
                node.addChild(child);
                p=parseTerminal(p, tableId, child);
            }
        }
        else{
            System.out.println("error of parseStmt");
            System.out.println(tokenList.get(p).getLineNum());
            System.out.println(tokenList.get(p).getContent());
        }
        token0 = new Token("", "<Stmt>",0);
        tokenListPlus.add(token0);
        return p;
    }
    public static int parseDecl(int p, int tableId, TreeNode node){
        if(tokenList.get(p).getType()=="CONSTTK"){
            child = new TreeNode(p,tableId,"<ConstDecl>");
            node.addChild(child);
            p=parseConstDecl(p, tableId, child);
            token0 = new Token("", "<Decl>",0);
            tokenListPlus.add(token0);
        }
        else if(tokenList.get(p).getType()=="INTTK"){
            child = new TreeNode(p,tableId,"<VarDecl>");
            node.addChild(child);
            p=parseVarDecl(p, tableId, child);
            token0 = new Token("", "<Decl>",0);
            tokenListPlus.add(token0);
        }
        else {
            System.out.println("error of parseDecl");
        }
        return p;
    }
    public static int parseConstDecl(int p, int tableId, TreeNode node){
        if(tokenList.get(p).getType()=="CONSTTK"){
            child = new TreeNode(p,tableId,"CONSTTK","const");
            node.addChild(child);
            p=parseTerminal(p, tableId, child);
        }
        else {
            System.out.println("error of parseConstDecl1");
        }
        child = new TreeNode(p,tableId,"<BType>");
        node.addChild(child);
        p=parseBType(p, tableId, child);

        child = new TreeNode(p,tableId,"<ConstDef>");
        node.addChild(child);
        p=parseConstDef(p, tableId, child);
        while(tokenList.get(p).getType()=="COMMA"){
            child = new TreeNode(p,tableId,"COMMA",",");
            node.addChild(child);
            p=parseTerminal(p, tableId, child);//,

            child = new TreeNode(p,tableId,"<ConstDef>");
            node.addChild(child);
            p=parseConstDef(p, tableId, child);
        }
        if(tokenList.get(p).getType()!="SEMICN"){
            int line = tokenList.get(p-1).getLineNum();
            error0 = new Error("i",line);
            errorList.add(error0);
            p++;
        }
        else {
            child = new TreeNode(p,tableId,"SEMICN",";");
            node.addChild(child);
            p=parseTerminal(p, tableId, child);//;
        }
        token0 = new Token("", "<ConstDecl>",0);
        tokenListPlus.add(token0);
        return p;
    }
    public static int parseConstDef(int p, int tableId, TreeNode node){
        if(tokenList.get(p).getType()!="IDENFR"){
            System.out.println("error1 in parseConstDef");
        }
        int p0 = p;
        int dem = 0;
        //**Ident
        child = new TreeNode(p,tableId,"IDENFR",tokenList.get(p).getContent());
        node.addChild(child);
        p=parseTerminal(p, tableId, child);
        //这个循环最多两次
        while(tokenList.get(p).getType()=="LBRACK"){
            child = new TreeNode(p,tableId,"LBRACK",tokenList.get(p).getContent());
            node.addChild(child);
            p=parseTerminal(p, tableId, child);//[

            child = new TreeNode(p,tableId,"<ConstExp>");
            node.addChild(child);
            p=parseConstExp(p, tableId, child);
            //System.out.println("<ConstExp> "+p);
            //检测有没有缺右方括号
            if(tokenList.get(p).getType().equals("RBRACK")) {
                child = new TreeNode(p,tableId,"RBRACK",tokenList.get(p).getContent());
                node.addChild(child);
                p=parseTerminal(p, tableId, child);//]
            }
            else {
                child = new TreeNode(p,tableId,"RBRACK","]");
                node.addChild(child);
                error0 = new Error("k",tokenList.get(p).getLineNum());
                errorList.add(error0);
                //System.out.println("<ConstExp> "+p);
                //p--;
            }
            dem++;
        }
        if(tokenList.get(p).getType()!="ASSIGN"){
            System.out.println("error2 in parseConstDef");
        }
        String token = tokenList.get(p0).getContent();
        if(queryNameDef(token, node.tableId)==1){
            error0 = new Error("b",getLine(node));
            errorList.add(error0);
        }
        else {
            Symbol symbol = new Symbol(tableId,token,dem,1);
            tableList.get(tableId).symbolList.put(token,symbol);
        }

        child = new TreeNode(p,tableId,"ASSIGN",tokenList.get(p).getContent());
        node.addChild(child);
        p=parseTerminal(p, tableId, child);//=

        child = new TreeNode(p,tableId,"<ConstInitVal>");
        node.addChild(child);
        p=parseConstInitVal(p, tableId, child);
        token0 = new Token("", "<ConstDef>",0);
        tokenListPlus.add(token0);
        return p;
    }
    public static int parseVarDef(int p, int tableId, TreeNode node){
        if(tokenList.get(p).getType()!="IDENFR"){
            System.out.println("error1 in parseVarDef");
        }
        int p0 = p;
        int dem = 0;
        child = new TreeNode(p,tableId,"IDENFR",tokenList.get(p).getContent());
        node.addChild(child);
        p=parseTerminal(p, tableId, child);
        while(tokenList.get(p).getType()=="LBRACK"){
            child = new TreeNode(p,tableId,"LBRACK",tokenList.get(p).getContent());
            node.addChild(child);
            p=parseTerminal(p, tableId, child);//[

            child = new TreeNode(p,tableId,"<ConstExp>");
            node.addChild(child);
            p=parseConstExp(p, tableId, child);

            if(tokenList.get(p).getType().equals("RBRACK")) {
                child = new TreeNode(p,tableId,"RBRACK",tokenList.get(p).getContent());
                node.addChild(child);
                p=parseTerminal(p, tableId, child);//]
            }
            else {
                child = new TreeNode(p,tableId,"RBRACK","]");
                node.addChild(child);
                error0 = new Error("k",tokenList.get(p).getLineNum());
                errorList.add(error0);
                //System.out.println("<ConstExp> "+p);
                //p--;
            }
            dem++;
        }
        if(tokenList.get(p).getType()=="ASSIGN"){
            child = new TreeNode(p,tableId,"ASSIGN",tokenList.get(p).getContent());
            node.addChild(child);
            p=parseTerminal(p, tableId, child);//=
            child = new TreeNode(p,tableId,"<InitVal>");
            node.addChild(child);
            p=parseInitVal(p, tableId, child);
        }

        String token = tokenList.get(p0).getContent();
        if(queryNameDef(token, node.tableId)==1){
            error0 = new Error("b",getLine(node));
            errorList.add(error0);
        }
        else {
            Symbol symbol = new Symbol(tableId,token,dem,0);
            tableList.get(tableId).symbolList.put(token,symbol);
        }

        token0 = new Token("", "<VarDef>",0);
        tokenListPlus.add(token0);
        return p;
    }
    public static int parseVarDecl(int p, int tableId, TreeNode node){
        child = new TreeNode(p,tableId,"<BType>");
        node.addChild(child);
        p=parseBType(p, tableId, child);

        child = new TreeNode(p,tableId,"<VarDef>");
        node.addChild(child);
        p=parseVarDef(p, tableId, child);
        while (tokenList.get(p).getType()=="COMMA"){
            child = new TreeNode(p,tableId,"COMMA",",");
            node.addChild(child);
            p=parseTerminal(p, tableId, child);
            child = new TreeNode(p,tableId,"<VarDef>");
            node.addChild(child);
            p=parseVarDef(p, tableId, child);
        }
        if(tokenList.get(p).getType()!="SEMICN"){
            int line = tokenList.get(p-1).getLineNum();
            error0 = new Error("i",line);
            errorList.add(error0);
            p++;
        }
        else {
            child = new TreeNode(p,tableId,"SEMICN",";");
            node.addChild(child);
            p=parseTerminal(p, tableId, child);
        }
        token0 = new Token("", "<VarDecl>",0);
        tokenListPlus.add(token0);
        return p;
    }
    public static FuncFParam parseFuncFParam(int p, int tableId, TreeNode node){
        FuncFParam f = new FuncFParam();
        int type = 0;
        child = new TreeNode(p,tableId,"<BType>");
        node.addChild(child);
        p=parseBType(p, tableId, child);
        //解析Ident
        f.name = tokenList.get(p).getContent();
        child = new TreeNode(p,tableId,"IDENFR",tokenList.get(p).getContent());
        node.addChild(child);
        p=parseTerminal(p, tableId, child);
        if(tokenList.get(p).getType()=="LBRACK"){
            child = new TreeNode(p,tableId,"LBRACK",tokenList.get(p).getContent());
            node.addChild(child);
            p=parseTerminal(p, tableId, child);//[
            /*
            child = new TreeNode(p,tableId,"RBRACK",tokenList.get(p).getContent());
            node.addChild(child);
            p=parseTerminal(p, tableId, child);//]
            */
            if(tokenList.get(p).getType().equals("RBRACK")) {
                child = new TreeNode(p,tableId,"RBRACK","]");
                node.addChild(child);
                p=parseTerminal(p, tableId, child);//]
            }
            else {
                child = new TreeNode(p,tableId,"RBRACK","]");
                node.addChild(child);
                error0 = new Error("k",tokenList.get(p).getLineNum());
                errorList.add(error0);

            }
            type++;
            if(tokenList.get(p).getType()=="LBRACK"){
                child = new TreeNode(p,tableId,"LBRACK",tokenList.get(p).getContent());
                node.addChild(child);
                p=parseTerminal(p, tableId, child);//[
                child = new TreeNode(p,tableId,"<ConstExp>",tokenList.get(p).getContent());
                node.addChild(child);
                p=parseConstExp(p, tableId, child);
                /*
                child = new TreeNode(p,tableId,"RBRACK",tokenList.get(p).getContent());
                node.addChild(child);
                p=parseTerminal(p, tableId, child);//]
                type++;
                 */
                if(tokenList.get(p).getType().equals("RBRACK")) {
                    child = new TreeNode(p,tableId,"RBRACK","]");
                    node.addChild(child);
                    p=parseTerminal(p, tableId, child);//]
                }
                else {
                    child = new TreeNode(p,tableId,"RBRACK","]");
                    node.addChild(child);
                    error0 = new Error("k",tokenList.get(p).getLineNum());
                    errorList.add(error0);
                }
            }
        }
        f.type=type;
        f.p=p;
        token0 = new Token("", "<FuncFParam>",0);
        tokenListPlus.add(token0);
        return f;
    }
    public static FuncFParam parseFuncFParams(int p, int tableId, TreeNode node){
        //每一个parseFuncFParam都要返回一个函数参数类型
        FuncFParam f0 = new FuncFParam();//这个用来存参数表
        FuncFParam f = new FuncFParam();
        child = new TreeNode(p,tableId,"<FuncFParam>");
        node.addChild(child);
        f=parseFuncFParam(p, tableId, child);
        p=f.p;
        f0.FuncFParams.add(f.type);
        f0.FuncFParamName.add(f.name);
        //int funcType = node.children.get(node.children.size()-1).FuncFParam;
        //node.FuncFParams.add(funcType);
        while(tokenList.get(p).getType()=="COMMA"){
            child = new TreeNode(p,tableId,"COMMA",tokenList.get(p).getContent());
            node.addChild(child);
            p=parseTerminal(p, tableId, child);//,
            int p_ident = tokenList.get(p).getLineNum();
            //System.out.println("p_ident "+p_ident);
            child = new TreeNode(p,tableId,"<FuncFParam>");
            node.addChild(child);
            f=parseFuncFParam(p, tableId, child);
            p=f.p;

            String token = f.name;
            if(f0.FuncFParamName.contains(token)){
                error0 = new Error("b",p_ident);
                errorList.add(error0);
            }
            else {
                f0.FuncFParams.add(f.type);
                f0.FuncFParamName.add(f.name);
            }
        }
        f0.p=p;
        token0 = new Token("", "<FuncFParams>",0);
        tokenListPlus.add(token0);
        return f0;
    }
    public static int parseFuncDef(int p, int tableId, TreeNode node){
        //要给当前的table添加一个Symbol
        ArrayList<Integer> FuncFParamsList = new ArrayList<Integer>();
        ArrayList<String> FuncFParamsNameList = new ArrayList<String>();
        int funcType = 3764;
        if(tokenList.get(p).getContent().equals("void")){
            funcType = 1;
        }
        else if(tokenList.get(p).getContent().equals("int")){
            funcType = 0;
        }
        child = new TreeNode(p,tableId,"<FuncType>");
        node.addChild(child);
        p=parseFuncType(p, tableId, child);
        String token = tokenList.get(p).getContent();
        int lineNum = tokenList.get(p).getLineNum();
        child = new TreeNode(p,tableId,tokenList.get(p).getType(),tokenList.get(p).getContent());
        node.addChild(child);
        p=parseTerminal(p, tableId, child);//Ident
        child = new TreeNode(p,tableId,tokenList.get(p).getType(),tokenList.get(p).getContent());
        node.addChild(child);
        p=parseTerminal(p, tableId, child);//(

        if(Objects.equals(tokenList.get(p).getType(), "RPARENT")){
            child = new TreeNode(p,tableId,tokenList.get(p).getType(),tokenList.get(p).getContent());
            node.addChild(child);
            p=parseTerminal(p, tableId, child);//)
        }
        else if(Objects.equals(tokenList.get(p).getType(),"LBRACE")){
                child = new TreeNode(p,tableId,"RPARENT","j");
                node.addChild(child);
                error0 = new Error("j",tokenList.get(p).getLineNum());
                errorList.add(error0);
        }
        else {
            //这个函数的参数数量和类型都需从FuncFParams中得知
            //也不一定是有参数，还可能是缺右小括号
            child = new TreeNode(p,tableId,"<FuncFParams>");
            node.addChild(child);
            FuncFParam f = parseFuncFParams(p, tableId, child);
            p=f.p;
            FuncFParamsList = f.FuncFParams;
            FuncFParamsNameList = f.FuncFParamName;
            //System.out.println("2132+"+FuncFParamsNameList+"="+FuncFParamsNameList);
            node.FuncFParams=FuncFParamsList;
            node.FuncFParamsName=FuncFParamsNameList;

            if(tokenList.get(p).getType().equals("RPARENT")) {
                child = new TreeNode(p,tableId,"RPARENT",")");
                node.addChild(child);
                p=parseTerminal(p, tableId, child);//)
            }
            else {
                child = new TreeNode(p,tableId,"RPARENT",")");
                node.addChild(child);
                error0 = new Error("j",tokenList.get(p).getLineNum());
                errorList.add(error0);
            }
        }
        child = new TreeNode(p,tableId,"<Block>");
        child.FuncFParams = FuncFParamsList;
        child.FuncFParamsName=FuncFParamsNameList;
        child.isInt = 1-funcType;
        node.addChild(child);
        p=parseBlock(p, tableId, child);
        Symbol symbol = new Symbol(tableId,token,-1,funcType,FuncFParamsList.size(),FuncFParamsList,FuncFParamsNameList);
        if(queryNameDef(token,tableId)==1){
            error0 = new Error("b",lineNum);
            errorList.add(error0);
        }
        else{
            tableList.get(tableId).symbolList.put(token,symbol);
        }
        token0 = new Token("", "<FuncDef>",0);
        tokenListPlus.add(token0);
        return p;
    }
    public static boolean isFormatStringValid(String s) {
        int n = s.length();
        if (n < 2 || s.charAt(0) != '"' || s.charAt(n - 1) != '"') {
            // 格式字符串必须以双引号包围
            return false;
        }
        boolean ans = true;
        for (int i = 1; i < n - 1; i++) {
            char currentChar = s.charAt(i);
            int ascii = (int) currentChar;
            if(ascii==37){//这是%
                if((int)s.charAt(i+1)==100){//这是d
                    continue;
                }
                else {
                    ans=false;
                    break;
                }
            }
            if(!(ascii==32||ascii==33||(ascii>=40&&ascii<=126)))
            {
                //System.out.println("2"+ascii);
                ans=false;
                break;
            }
            if(ascii==92){
                //System.out.println("ewde");
                if((int)s.charAt(i+1)!=110){
                    ans=false;
                }
            }
        }
        return ans;
    }
    public static String getCode(String s) {
        if ("main".equals(s)) {
            return "MAINTK";
        } else if ("const".equals(s)) {
            return "CONSTTK";
        } else if ("int".equals(s)) {
            return "INTTK";
        } else if ("break".equals(s)) {
            return "BREAKTK";
        } else if ("continue".equals(s)) {
            return "CONTINUETK";
        } else if ("if".equals(s)) {
            return "IFTK";
        } else if ("else".equals(s)) {
            return "ELSETK";
        } else if ("for".equals(s)) {
            return "FORTK";
        } else if ("getint".equals(s)) {
            return "GETINTTK";
        } else if ("printf".equals(s)) {
            return "PRINTFTK";
        } else if ("return".equals(s)) {
            return "RETURNTK";
        } else if ("void".equals(s)) {
            return "VOIDTK";
        } else {
            return null;
        }
    }
    public static String readIdentifier(String input, int startIndex) {
        StringBuilder identifier = new StringBuilder();
        int index = startIndex;
        // 判断当前字符是否是字母、下划线或数字
        while (index < input.length() && (Character.isLetterOrDigit(input.charAt(index)) || input.charAt(index) == '_')) {
            identifier.append(input.charAt(index));
            index++;
        }
        return identifier.toString();
    }
    public static String readNumberString(String input, int startIndex) {
        StringBuilder numberString = new StringBuilder();
        int i = startIndex;

        // 从指定下标开始查找数字字符
        while (i < input.length() && !Character.isDigit(input.charAt(i))) {
            i++;
        }

        // 从找到的数字字符开始读取数字串
        while (i < input.length() && Character.isDigit(input.charAt(i))) {
            numberString.append(input.charAt(i));
            i++;
        }

        return numberString.toString();
    }
    public static String removeMultiLineComments(String input) {
        String result="";
        //真值表示现在在注释中
        boolean state=false;
        //真值表示在字符串中
        boolean state1=false;

        for(int i=0;i<input.length();i++){
            //在字符串中
            if(state1){
                if(input.charAt(i)=='"'){
                    state1=!state1;
                    result=result+input.charAt(i);
                }
                else{
                    result=result+input.charAt(i);
                }
            }
            else{
                //不在注释中
                if(!state){
                    if(input.charAt(i)=='/'&&input.charAt(i+1)=='*'){
                        state=true;
                        i++;
                    }
                    else if(input.charAt(i)=='"'){
                        state1=true;
                        result=result+input.charAt(i);
                    }
                    else{
                        result=result+input.charAt(i);
                    }
                }
                //在注释中
                else{
                    if(input.charAt(i)=='*'&&input.charAt(i+1)=='/'){
                        state=false;
                        i++;
                    }
                    else{
                        if(input.charAt(i)=='\n'){
                            result=result+"\n";
                        }
                    }
                }
            }
        }
        return result;
    }
    public static String removeSingleLineComments(String input) {
        String result="";
        //真值表示现在在注释中
        boolean state=false;
        //真值表示在字符串中
        boolean state1=false;
        for(int i=0;i<input.length();i++){
            //在字符串中
            if(state1){
                if(input.charAt(i)=='"'){
                    state1=!state1;
                    result=result+input.charAt(i);
                }
                else{
                    result=result+input.charAt(i);
                }
            }
            //不在字符串中
            else{
                //不在注释中
                if(!state){
                    if(input.charAt(i)=='/'&&input.charAt(i+1)=='/'){
                        state=true;
                        i++;
                    }
                    else if(input.charAt(i)=='"'){
                        state1=true;
                        result=result+input.charAt(i);
                    }
                    else{
                        result=result+input.charAt(i);
                    }
                }
                //在注释中
                else{
                        if(input.charAt(i)=='\n'){
                            result=result+"\n";
                            state=false;
                        }
                }
            }
        }
        return result;
    }
    public static void printTokenList(ArrayList<Token> tokenList) {
        for (Token token : tokenList) {
            System.out.println(token.toString());
        }
    }
    /*
    public static void addSymbolTable(String name){
        Symbol s = new Symbol();
        //s=name.t
        tableList.get(tableNum).addToSymbolList(s);
    }
    //给定一个变量名。判断能否插入当前符号表，能则返回0，否则返回-1
    public static int isInsertable(String name){
        Table table0 = tableList.get(tableNum);
        for(int i=0;i<table0.getSymbolList().size();i++){
            if(table0.getSymbolList().get(i).getName().equals(name)){
                return -1;
            }
        }
        return 0;
    }
     */
    public static void printTable(){
        for(int i=0;i<tableList.size();i++){
            System.out.print(tableList.get(i).isInt);
            System.out.println("id为"+tableList.get(i).id+"的表的信息有：");
            HashMap<String, Symbol> map = tableList.get(i).symbolList;
            for (Map.Entry<String, Symbol> entry : map.entrySet()) {
                //String token = entry.getKey();
                Symbol value = entry.getValue();
                System.out.println(value.toString());
            }

        }
    }
    public static void postOrderTraversalToFile(TreeNode root) {
        try {
            FileWriter fileWriter = new FileWriter("output.txt");
            postOrderTraversal(root, fileWriter);
            fileWriter.close(); // 关闭文件
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static void postOrderTraversal(TreeNode root, FileWriter fileWriter) throws IOException {
        if (root == null) {
            return;
        }
        // 遍历根节点的子节点
        for (TreeNode child : root.getChildren()) {
            postOrderTraversal(child, fileWriter);
        }
        // 访问根节点
        if (!(root.content == null || root.content.equals(""))) {
            if (!(root.type.equals("<BlockItem>") || root.type.equals("<Decl>") || root.type.equals("<BType>"))) {
                fileWriter.write(root.type+" "+root.content + System.lineSeparator()); // 写入文件并换行
            }
        } else {
            fileWriter.write(root.type + System.lineSeparator()); // 写入文件并换行
        }
    }
    public static void errorHandle(TreeNode root) {
        if (root == null) {
            return;
        }
        // 遍历根节点的子节点
        for (TreeNode child : root.getChildren()) {
            errorHandle(child);
        }
        //重定义类错误 b
        /*
        if(Objects.equals(root.type, "<ConstDef>")||Objects.equals(root.type, "<VarDef>")){
            String ident = root.children.get(0).content;
            if(queryNameDef(ident, root.tableId)==1){
                error0 = new Error("b",getLine(root));
                errorList.add(error0);
            }
        }
        */
        //声明类错误（未定义的名字） c
        if(Objects.equals(root.type, "<LVal>")||Objects.equals(root.type, "<UnaryExp>")){
            if(root.children.get(0).type=="IDENFR"){
                String ident = root.children.get(0).content;
                if(queryNameUse(ident, root.tableId)==0){
                    //如果没查到
                    //System.out.println("rootLine "+getLine(root)+" "+root.children.get(0));
                    error0 = new Error("c",getLine(root));
                    errorList.add(error0);
                    System.out.println("c :"+ident);
                }
            }
        }
        //函数参数个数不匹配 d 类型不匹配 e
        if(Objects.equals(root.type, "<UnaryExp>")){
            if(root.children.size()==3){//形如f()
                System.out.println("wuquwedqiw   ");
                if(root.children.get(0).FuncFParamsName==null){

                }
                else if(root.children.get(0).FuncFParamsName.size()==0){

                }
                else if(root.children.get(0).FuncFParamsName.size()!=0){
                    error0 = new Error("d",getLine(root));
                    errorList.add(error0);
                }
            }
            else if(root.children.size()==4)//形如f(...)
            {
                System.out.println("ewewe   "+root.children.get(3).content);
                Symbol ident = getName(root.children.get(0).content,root.tableId);
                //System.out.println(" rfr "+root.children.get(2).FuncRParamsType.size());
                if(ident.paramTypeList.size()!=root.children.get(2).FuncRParamsType.size()){
                    error0 = new Error("d0",getLine(root));
                    errorList.add(error0);
                }
                else {//个数匹配且不为0，检测类型是否匹配 e
                    //System.out.println();
                    if(!ident.paramTypeList.equals(root.children.get(2).FuncRParamsType)){
                        error0 = new Error("e",getLine(root));
                        errorList.add(error0);
                    }
                }
            }
        }
        //无返回值的函数存在不匹配的return语句 f
        if(Objects.equals(root.type, "<Stmt>")){
            //如果不是返回值为int的函数
            if(Objects.equals(root.children.get(0).content, "return")&&tableList.get(root.tableId).isInt!=1&&root.children.size()==3){
                error0 = new Error("f",getLine(root));
                errorList.add(error0);
            }
        }
        //有返回值的函数缺少return语句 g
        if(Objects.equals(root.type, "<Block>")){
            //System.out.println("uwncqecnie "+root.children.get(root.children.size()-2).type);
            //block的id直接从node.tableId获取
            //如果这个函数体里没有语句
            if(tableList.get(root.tableId).isInt==1&&root.children.size()==2){
                error0 = new Error("g",root.children.get(root.children.size()-1).line);
                errorList.add(error0);
            }
            else{
                if(tableList.get(root.tableId).isInt==1&&root.children.get(root.children.size()-2).type=="<BlockItem>"){
                    TreeNode node_BlockItem = root.children.get(root.children.size()-2);
                    //System.out.println("21321  32  "+tokenList.get(node_BlockItem.p).getContent());
                    if(!Objects.equals(tokenList.get(node_BlockItem.p).getContent(), "return")){
                        error0 = new Error("g",root.children.get(root.children.size()-1).line);
                        errorList.add(error0);
                    }
                    //TreeNode Stmt = node_BlockItem.children.get(0);
                }
            }
        }
        //不能改变常量的值	h
        if(Objects.equals(root.type, "<Stmt>")){
            TreeNode LVal = root.children.get(0);
            if(Objects.equals(LVal.type,"<LVal>")){
                String token = LVal.children.get(0).content;
                int tableId  = LVal.tableId;
                if(getName(token,tableId)!=null){
                    if(getName(token,tableId).con==1){
                        error0 = new Error("h",getLine(LVal));
                        errorList.add(error0);
                    }
                }
            }
        }
        //在非循环块中使用break和continue语句 m
        if(Objects.equals(root.type, "<Stmt>")){
            if(Objects.equals(root.children.get(0).content, "break") || Objects.equals(root.children.get(0).content, "continue")){
                if(tokenList.get(root.p).isLoop==0){
                    error0 = new Error("m",getLine(root));
                    errorList.add(error0);
                }
            }
        }
    }
    public static int judgeReverse(TreeNode node){
        if(node.children.size()==3){
            if(node.children.get(0).type.equals("<AddExp>")||
                    node.children.get(0).type.equals("<MulExp>")||
                    node.children.get(0).type.equals("<RelExp>")||
                    node.children.get(0).type.equals("<UnaryExp>")||
                    node.children.get(0).type.equals("<EqExp>")||
                    node.children.get(0).type.equals("<LAndExp>")
            ){
                // 交换第一个和第三个节点
                TreeNode firstChild = node.children.get(0);
                TreeNode thirdChild = node.children.get(2);

                // 交换节点内容
                node.children.set(0, thirdChild);
                node.children.set(2, firstChild);
                return 1;
            }
        }
        return 0;
    }
    //递归向上查找
    public static int queryNameUse(String token,int tableId){
        System.out.println("21ds3  "+token + " "+tableId);
        while(tableId>=0){
            Table t0 = tableList.get(tableId);
            if(t0.symbolList.containsKey(token)){
                return 1;
            }
            else{
                tableId = t0.fatherId;
            }
        }
        return 0;
    }
    public static Symbol getName(String token,int tableId){
        while(tableId>=0){
            Table t0 = tableList.get(tableId);
            if(t0.symbolList.containsKey(token)){
                return t0.symbolList.get(token);
            }
            else{
                tableId = t0.fatherId;
            }
        }
        return null;
    }
    //只在当前符号表查找
    public static int queryNameDef(String token,int tableId){
       Table t0 = tableList.get(tableId);
       if(t0.symbolList.containsKey(token)){
           return 1;
       }
       return 0;
    }
    public static int getLine(TreeNode node){
        while (node.children.size()!=0){
            node=node.children.get(0);
        }
        return node.line;
    }
    public static void setLoop(){
        int loop = 0;
        for (int i=0; i<tokenList.size(); i++){
            if(tokenList.get(i).loopStart==1){
                loop++;
            }
            if(tokenList.get(i).loopEnd==1){
                loop--;
            }
            if(loop>0){
                tokenList.get(i).isLoop=1;
            }
        }
    }
    public static void sortErrorList() {
        // 使用 Collections.sort() 方法，并传入一个自定义的 Comparator
        Collections.sort(errorList, new Comparator<Error>() {
            @Override
            public int compare(Error error1, Error error2) {
                // 根据 lineNumber 属性升序排序
                return Integer.compare(error1.getLineNumber(), error2.getLineNumber());
            }
        });
    }
    /*
    public static void generate(TreeNode node) {
        if (node == null) {
            return;
        }
        // 遍历根节点的子节点
        for (TreeNode child : node.getChildren()) {
            generate(child);
        }
        if(node.type.equals("<MainFuncDef>")){
            Line line = new Line(0,"define dso_local i32 @main() {");
        }
    }*/
    public static void produceMiddle(TreeNode root){
        switch (root.type) {
            case "<ConstDef>":
                generateConstDef(root);
                break;
            case "<ConstInitVal>":
            case "<InitVal>":
                generateConstInitVal(root);
                break;
            case "<ConstExp>":
                generateConstExp(root);
                break;
            case "<VarDef>":
                generateVarDef(root);
                break;
            case "<FuncDef>":
                generateFuncDef(root);
                break;
            case "<FuncFParams>":
                generateFuncFParams(root);
                break;
            case "<FuncFParam>":
                generateFuncFParam(root);
                break;
            case "<MainFuncDef>":
                generateMainFuncDef(root);
                break;
            case "<Block>":
                generateBlock(root);
                break;
            case "<Stmt>":
                generateStmt(root);
                break;
            case "<forStmt>":
                generateForStmt(root);
                break;
            case "<Number>":
                generateNumber(root);
                break;
            case "<Exp>":
                generateExp(root);
                break;
            case "<Cond>":
                generateCond(root);
                break;
            case "<LVal>":
                generateLVal(root);
                break;
            case "<FuncRParams>":
                generateFuncRParams(root);
                break;
            case "<PrimaryExp>":
                generatePrimaryExp(root);
                break;
            case "<UnaryExp>":
                generateUnaryExp(root);
                break;
            case "<MulExp>":
            case "<AddExp>":
                generateAddMulExp(root);
                break;
            case "<RelExp>":
            case "<EqExp>":
                generateRelEqExp(root);
                break;
            case "<LAndExp>":
                generateLAndExp(root);
                break;
            case "<LOrExp>":
                generateLOrExp(root);
                break;
            default:
                for (int i = 0; i < root.getChildren().size(); i++) {
                    produceMiddle(root.getChildren().get(i));
                }
                break;
        }
    }
    /*public static void Block(TreeNode ast){
        generate(ast.getChildren().get(1));//
    }
     */
    /*
    public static void Block(TreeNode ast){
        ArrayList<TreeNode> a=ast.children;
        for(int i=0;i<a.size();i++){
            if(a.get(i).type.equals("{")){}//符号表相关操作
            else if(a.get(i).type.equals("}")){}//符号表相关操作
            else{generate(a.get(i));}//遍历，无需判断是Stmt还是ConstDecl还是VarDecl
        }
    }
    public static void Stmt(TreeNode ast){
        ArrayList<TreeNode> a=ast.children;
        if(a.get(0).type.equals("<Block>")){generate(a.get(0));}
        else if(a.get(0).type.equals("RETURNTK")){
            if(a.get(1).type.equals("SEMICN")){}
            else{
                generate(a.get(1));//Exp
                output(tab+"ret i32 "+a.get(1).getValue()+"");
                //tabLine()可有可无，只是为了缩进好看所以加的QAQ
            }
        }
    }
    public static void AddExp(TreeNode ast){
        ArrayList<TreeNode> a=ast.children;
        generate(a.get(0));//运行下层函数
        ast.setValue(a.get(0).getValue());//把子节点的值传递给上层
    }
    public static void MulExp(TreeNode ast){
        ArrayList<TreeNode> a=ast.children;
        generate(a.get(0));//运行下层函数
        ast.setValue(a.get(0).getValue());//把子节点的值传递给上层
    }
    public static void UnaryExp(TreeNode ast){
        ArrayList<TreeNode> a=ast.children;
        generate(a.get(0));//运行下层函数
        ast.setValue(a.get(0).getValue());//把子节点的值传递给上层
    }
    public static void PrimaryExp(TreeNode ast){
        ArrayList<TreeNode> a=ast.children;
        generate(a.get(0));//运行下层函数
        ast.setValue(a.get(0).getValue());//把子节点的值传递给上层
    }
    public static void Exp(TreeNode ast){
        ArrayList<TreeNode> a=ast.children;
        generate(a.get(0));//运行下层函数
        ast.setValue(a.get(0).getValue());//把子节点的值传递给上层
    }
    */
    public static void generateMainFuncDef(TreeNode node){
        System.out.println("MainFuncDef called successfully");
        addLineToLLVM("\ndefine dso_local i32 @main() {");
        produceMiddle(node.children.get(4));//Block
        addLineToLLVM("}\n");
    }
    public static void generateBlock(TreeNode node){
        //Block → '{' { BlockItem } '}'
        //System.out.println("Block called successfully");
        ArrayList<TreeNode> childrenList=node.children;
        for (TreeNode treeNode : childrenList) {
            //System.out.println("Block called successfully1111");
            if (treeNode.type.equals("LBRACE")) {
                level++;
                if (level == 1) {
                    nowTag += 1;
                }
                //level+=1;
                if (level == 1) {
                    for (int j = stack.size() - 1; j >= 0; j--) {
                        if (stack.get(j).getRegId().equals("") && stack.get(j).level == 1) {
                            addLineToLLVM(tabLine() + "%v" + regId + " = alloca " + stack.get(j).getKey().addressType);
                            stack.get(j).setRegId("%v" + regId);
                            addLineToLLVM(tabLine() + "store " + stack.get(j).getKey().addressType + " " + stack.get(j).getValue() + ", " + stack.get(j).getKey().addressType + " * " + stack.get(j).getRegId());
                            regId++;
                        }
                    }
                }
            } else if (treeNode.type.equals("RBRACE")) {
                for (int j = stack.size() - 1; j >= 0; j--) {
                    if (stack.get(j).level == level) {
                        stack.remove(j);
                    }
                }
                level -= 1;
                if (level == 0) {
                    nowTag -= 1;
                }
            } else {
                treeNode.setContinueId(node.getContinueId());
                treeNode.setBreakId(node.getBreakId());
                produceMiddle(treeNode);//BlockItem
            }
        }
    }
    public static void generateStmt(TreeNode node){
        ArrayList<TreeNode> childrenList=node.children;
        switch (childrenList.get(0).type) {
            case "<Block>":
                //这个有没有用待考证
                childrenList.get(0).setContinueId(node.getContinueId());
                childrenList.get(0).setBreakId(node.getBreakId());
                produceMiddle(childrenList.get(0));
                break;
            case "RETURNTK":
                if (childrenList.get(1).type.equals("SEMICN")) {
                    addLineToLLVM(tabLine() + "ret void");
                } else {
                    produceMiddle(childrenList.get(1));//Exp
                    addLineToLLVM(tabLine() + "ret i32 " + childrenList.get(1).getValue());//getValue得到的是一个寄存器编号（如%v1），其中存储返回值
                }
                break;
            case "<LVal>":
                produceMiddle(childrenList.get(0));//LVal

                if (childrenList.get(2).type.equals("<Exp>")) {
                    produceMiddle(childrenList.get(2));//Exp
                    addLineToLLVM(tabLine() + "store i32 " + childrenList.get(2).getValue() + ", i32* " + childrenList.get(0).getRegId());
                } else if (childrenList.get(2).type.equals("GETINTTK")) {
                    addLineToLLVM(tabLine() + "%v" + regId + " = call i32 @getint()");
                    addLineToLLVM(tabLine() + "store i32 " + "%v" + regId + ", i32* " + childrenList.get(0).getRegId());
                    regId++;
                }
                break;
            case "<Exp>":
                produceMiddle(childrenList.get(0));
                break;
            case "PRINTFTK":
                int parNum = 4;
                String s = childrenList.get(2).content;//FormatString

                //先解析所有Exp
                for (int i = 1; i < s.length() - 1; i++) {
                    if (s.charAt(i) == '%' && s.charAt(i + 1) == 'd') {
                        i++;
                        produceMiddle(childrenList.get(parNum));//Exp的有关信息会存到value里
                        parNum += 2;
                    }
                }
                parNum = 4;
                for (int i = 1; i < s.length() - 1; i++) {
                    if (s.charAt(i) == '%' && s.charAt(i + 1) == 'd') {
                        i++;
                        addLineToLLVM(tabLine() + "call void @putint(i32 " + childrenList.get(parNum).getValue() + ")");
                        parNum += 2;
                    } else if (s.charAt(i) == '\\' && s.charAt(i + 1) == 'n') {
                        i++;
                        addLineToLLVM(tabLine() + "call void @putch(i32 10)");
                    } else {
                        addLineToLLVM(tabLine() + "call void @putch(i32 " + (int) s.charAt(i) + ")");
                    }
                }
                break;
            case "IFTK": {
                addLineToLLVM(tabLine() + "br label %v" + regId);
                addLineToLLVM("\nv" + regId + ":\n");
                childrenList.get(2).setYesId(regId + 1);
                int YesId = regId + 1;
                int NoId = 0;
                int StmtId;
                if (childrenList.size() > 5) {
                    childrenList.get(2).setNoId(regId + 2);
                    childrenList.get(2).setStmtId(regId + 3);
                    childrenList.get(4).setStmtId(regId + 3);
                    childrenList.get(4).setContinueId(node.getContinueId());
                    childrenList.get(4).setBreakId(node.getBreakId());
                    childrenList.get(6).setStmtId(regId + 3);
                    childrenList.get(6).setContinueId(node.getContinueId());
                    childrenList.get(6).setBreakId(node.getBreakId());
                    NoId = regId + 2;
                    StmtId = regId + 3;
                    regId += 4;
                } else {
                    childrenList.get(2).setNoId(regId + 2);
                    childrenList.get(2).setStmtId(regId + 2);
                    childrenList.get(4).setStmtId(regId + 2);
                    childrenList.get(4).setContinueId(node.getContinueId());
                    childrenList.get(4).setBreakId(node.getBreakId());
                    StmtId = regId + 2;
                    regId += 3;
                }
                produceMiddle(childrenList.get(2));
                addLineToLLVM("\nv" + YesId + ":\n");
                produceMiddle(childrenList.get(4));
                if (childrenList.size() > 5) {
                    addLineToLLVM("\nv" + NoId + ":\n");
                    produceMiddle(childrenList.get(6));
                }
                addLineToLLVM("\nv" + StmtId + ":\n");
                break;
            }
            case "WHILETK": {
                addLineToLLVM(tabLine() + "br label %v" + regId);
                addLineToLLVM("\nv" + regId + ":\n");
                int YesId = regId + 1;
                int StmtId = regId + 2;
                childrenList.get(2).setYesId(regId + 1);
                childrenList.get(2).setNoId(regId + 2);
                childrenList.get(2).setStmtId(regId + 2);
                childrenList.get(4).setStmtId(regId);
                childrenList.get(4).setBreakId(regId + 2);
                childrenList.get(4).setContinueId(regId);
                regId += 3;
                produceMiddle(childrenList.get(2));
                addLineToLLVM("\nv" + YesId + ":\n");
                produceMiddle(childrenList.get(4));
                addLineToLLVM("\nv" + StmtId + ":\n");
                break;
            }
            case "FORTK": {
                addLineToLLVM(tabLine() + "br label %v" + regId);
                addLineToLLVM("\nv" + regId + ":\n");
                int count = 0;
                int CondId = regId + 1;
                int YesId = regId + 2;
                int NoId = regId + 3;
                int StmtId = regId + 4;
                regId += 5;
                int for2 = 0;
                int i = 0;
                boolean hasForStmt = false;
                boolean hasCond = false;
                for (; i < childrenList.size(); i++) {
                    if (count >= 2) {
                        break;
                    }
                    if (childrenList.get(i).type.equals("SEMICN")) {
                        count += 1;
                    }
                    if (childrenList.get(i).type.equals("<forStmt>")) {
                        hasForStmt = true;
                        childrenList.get(i).setStmtId(CondId);
                        produceMiddle(childrenList.get(i));

                    }
                    if (childrenList.get(i).type.equals("<Cond>")) {
                        addLineToLLVM("\nv" + CondId + ":\n");
                        hasCond = true;
                        childrenList.get(i).setYesId(YesId);
                        childrenList.get(i).setNoId(NoId);
                        childrenList.get(i).setStmtId(CondId);
                        produceMiddle(childrenList.get(i));
                    }
                    if (count == 1 && !hasForStmt) {
                        addLineToLLVM(tabLine() + "br label %v" + CondId);
                    }
                    if (count == 2 && !hasCond) {
                        addLineToLLVM("\nv" + CondId + ":\n");
                        addLineToLLVM(tabLine() + "br label %v" + YesId);
                    }
                }
                for (; i < childrenList.size(); i++) {
                    if (childrenList.get(i).type.equals("<forStmt>")) {
                        for2 = i;
                    }
                    if (childrenList.get(i).type.equals("<Stmt>")) {
                        addLineToLLVM("\nv" + YesId + ":\n");
                        childrenList.get(i).setStmtId(StmtId);
                        childrenList.get(i).setBreakId(NoId);
                        childrenList.get(i).setContinueId(StmtId);
                        produceMiddle(childrenList.get(i));
                    }
                }
                addLineToLLVM("\nv" + StmtId + ":");
                if (for2 == 0) {
                    addLineToLLVM(tabLine() + "br label %v" + CondId);
                } else {
                    childrenList.get(for2).setStmtId(CondId);
                    produceMiddle(childrenList.get(for2));
                }
                addLineToLLVM("\nv" + NoId + ":");

                break;
            }
            case "BREAKTK":
                node.setStmtId(node.getBreakId());
                break;
            case "CONTINUETK":
                node.setStmtId(node.getContinueId());
                break;
        }
        if(node.stmtId !=0){
            addLineToLLVM(tabLine()+"br label %v"+node.stmtId);
        }
    }
    public static void generateExp(TreeNode node){
        produceMiddle(node.children.get(0));//AddExp
        node.setValue(node.children.get(0).getValue());
        node.setRegId(node.children.get(0).getRegId());
        node.setKey(node.children.get(0).getKey());
    }
    public static void generatePrimaryExp(TreeNode node){
        //PrimaryExp → '(' Exp ')' | LVal | Number
        ArrayList<TreeNode> childrenList=node.children;
        if(childrenList.get(0).type.equals("<Number>")){
            produceMiddle(childrenList.get(0));//Number
            node.setValue(childrenList.get(0).getValue());
        }
        else if(childrenList.get(0).type.equals("LPARENT")){
            produceMiddle(childrenList.get(1));//Exp
            node.setValue(childrenList.get(1).getValue());
        }
        else if(childrenList.get(0).type.equals("<LVal>")){
            produceMiddle(childrenList.get(0));//LVal
            node.setValue(childrenList.get(0).getValue());
            //比上面多了两步？
            node.setRegId(childrenList.get(0).getRegId());
            node.setKey(childrenList.get(0).getKey());
        }
    }
    public static void generateUnaryExp(TreeNode node){
        //UnaryExp → PrimaryExp | Ident '(' [FuncRParams] ')' | UnaryOp UnaryExp
        ArrayList<TreeNode> childrenList=node.children;
        if(childrenList.get(0).type.equals("<UnaryOp>")){
            produceMiddle(childrenList.get(1));//UnaryExp
            if(childrenList.get(0).children.get(0).type.equals("MINU")){
                if(level>0){
                    addLineToLLVM(tabLine()+"%v"+regId+" = sub i32 0, "+childrenList.get(1).getValue());
                    node.setRegId("%v"+regId);
                    node.setValue("%v"+regId);
                    regId++;
                }
                else{
                    node.setValue(mathCalculate("0","-",childrenList.get(1).getValue()));
                }
            }
            else if(childrenList.get(0).children.get(0).type.equals("PLUS")){node.setValue(childrenList.get(1).getValue());}
            else if(childrenList.get(0).children.get(0).type.equals("NOT")){
                addLineToLLVM(tabLine()+"%v"+regId+" = icmp eq i32 0, "+childrenList.get(1).getValue());
                regId++;
                addLineToLLVM(tabLine()+"%v"+regId+" = zext i1 %v"+(regId-1)+" to i32");
                node.setRegId("%v"+regId);
                node.setValue("%v"+regId);
                regId++;
            }
        }
        else if(childrenList.get(0).type.equals("<PrimaryExp>")){
            produceMiddle(childrenList.get(0));//PrimaryExp
            node.setValue(childrenList.get(0).getValue());
            node.setRegId(childrenList.get(0).getRegId());
            node.setKey(childrenList.get(0).getKey());
        }
        else if(childrenList.size()>2&&childrenList.get(1).type.equals("LPARENT")){
            TreeNode ident=childrenList.get(0);
            String identName = ident.content;
            TreeNode identGlobal=global.get(identName);
            ident.setReturnType(identGlobal.getReturnType());
            if(ident.getReturnType().equals("i32")){
                if(childrenList.get(2).type.equals("RPARENT")){
                    addLineToLLVM(tabLine()+"%v"+regId+" = call "+ident.getReturnType()+" @"+ident.content+"()");
                    node.setValue("%v"+regId);
                    regId++;
                }
                else{
                    produceMiddle(childrenList.get(2));
                    addLineToLLVM(tabLine()+"%v"+regId+" = call "+ident.getReturnType()+" @"+ident.getContent()+"("+childrenList.get(2).getValue()+")");
                    node.setValue("%v"+regId);
                    regId++;
                }
            }
            else if(ident.getReturnType().equals("void")){
                if(childrenList.get(2).type.equals("RPARENT")){
                    addLineToLLVM(tabLine()+"call "+ident.getReturnType()+" @"+ident.getContent()+"()");
                }
                else{
                    produceMiddle(childrenList.get(2));
                    addLineToLLVM(tabLine()+"call "+ident.getReturnType()+" @"+ident.getContent()+"("+childrenList.get(2).getValue()+")");
                }
            }
        }
    }
    public static void generateAddMulExp(TreeNode node){
        //以AddExp为例
        //AddExp → MulExp | AddExp ('+' | '−') MulExp
        System.out.println("AddMulExp called successfully");
        ArrayList<TreeNode> childrenList=node.children;
        produceMiddle(childrenList.get(0));//AddExp/MulExp
        String left_value=childrenList.get(0).getValue();
        if(childrenList.size()>1){
            //从第二个MulExp开始，一直遍历到最后一个MulExp
            for(int i=1;i<childrenList.size();i+=2){
                String op=childrenList.get(i).getContent();
                produceMiddle(childrenList.get(i+1));
                String right=childrenList.get(i+1).getValue();
                String opt= opToOperation(op);
                //如果不是全局
                if(level>0){
                    addLineToLLVM(tabLine()+"%v"+regId+" = "+opt+" i32 "+left_value+", "+right);
                    childrenList.get(i+1).setRegId("%v"+regId);
                    childrenList.get(i+1).setValue("%v"+regId);
                    regId++;
                }
                //如果是全局，直接算，不输出计算过程的llvm语句
                else{
                    childrenList.get(i+1).setValue(mathCalculate(left_value,op,right));
                }
                //把所有算完的都合并到left
                left_value=childrenList.get(i+1).getValue();
            }
            node.setValue(childrenList.get(childrenList.size()-1).getValue());
        }
        //如果AddExp下只有一个MulExp节点
        else{
            node.setKey(childrenList.get(0).getKey());
            node.setValue(left_value);
            node.setRegId(childrenList.get(0).getRegId());
        }
    }
    public static void generateRelEqExp(TreeNode node){
        ArrayList<TreeNode> a=node.children;
        produceMiddle(a.get(0));//RelExp/EqExp
        String left=a.get(0).getValue();
        if(a.size()>1){
            for(int i=1;i<a.size();i+=2){
                String op=a.get(i).getContent();
                produceMiddle(a.get(i+1));
                String right=a.get(i+1).getValue();
                String opt=opToOperation(op);
                if(level>0){
                    addLineToLLVM(tabLine()+"%v"+regId+" = icmp "+opt+" i32 "+left+", "+right+"\n");
                    regId++;
                    addLineToLLVM(tabLine()+"%v"+regId+" = zext i1 %v"+(regId-1)+" to i32\n");
                    a.get(i+1).setRegId("%v"+regId);
                    a.get(i+1).setValue("%v"+regId);
                    regId++;
                }
                else{
                    a.get(i+1).setValue(mathCalculate(left,op,right));
                }
                left=a.get(i+1).getValue();
            }
            node.setValue(a.get(a.size()-1).getValue());
        }
        else{
            node.setValue(left);
        }
    }
    public static void generateLAndExp(TreeNode node){
        // LAndExp → EqExp | LAndExp '&&' EqExp
        ArrayList<TreeNode> a=node.children;
        if(a.size()==1){
            produceMiddle(a.get(0));
            node.setValue(a.get(0).getValue());
        }
        else{
            for(int i=0;i<a.size()-2;i+=2){
                produceMiddle(a.get(i));//LAndExp
                addLineToLLVM(tabLine()+"%v"+regId+" = icmp ne i32 0, "+a.get(i).getValue()+"\n");
                addLineToLLVM(tabLine()+"br i1 %v"+regId+", label %v"+(regId+1)+", label %v"+node.noId+"\n");
                regId+=2;
                addLineToLLVM("\nv"+(regId-1)+":\n");
            }
            int max=a.size()-1;
            produceMiddle(a.get(max));
            if(a.size()==1){
                node.setValue(a.get(max).getValue());
            }
            addLineToLLVM(tabLine()+"%v"+regId+" = icmp ne i32 0, "+a.get(max).getValue()+"\n");
            addLineToLLVM(tabLine()+"br i1 %v"+regId+", label %v"+node.yesId+", label %v"+node.noId+"\n");
            regId+=1;

        }
    }
    public static void generateLOrExp(TreeNode node){
        ArrayList<TreeNode> a=node.children;
        for(int i=0;i<a.size()-2;i+=2){
            if(a.get(i).children.get(0).children.size()==1){
                produceMiddle(a.get(i).children.get(0));//LOrExp
                addLineToLLVM(tabLine()+"%v"+regId+" = icmp ne i32 0, "+a.get(i).children.get(0).getValue()+"\n");
                addLineToLLVM(tabLine()+"br i1 %v"+regId+", label %v"+node.yesId+", label %v"+(regId+1)+"\n");
                regId+=2;
                addLineToLLVM("\nv"+(regId-1)+":\n");
            }
            else{
                a.get(i).setYesId(node.yesId);
                a.get(i).setStmtId(node.getStmtId());

                a.get(i).setNoId(regId);
                regId++;
                produceMiddle(a.get(i));//特殊
                addLineToLLVM("\nv"+a.get(i).noId+":\n");
            }
        }
        int max=a.size()-1;
        if(a.get(max).children.size()==1){
            produceMiddle(a.get(max));//LOrExp
            addLineToLLVM(tabLine()+"%v"+regId+" = icmp ne i32 0, "+a.get(max).getValue()+"\n");
            addLineToLLVM(tabLine()+"br i1 %v"+regId+", label %v"+node.yesId+", label %v"+node.noId+"\n");
            regId+=1;
        }
        else{
            a.get(max).setYesId(node.yesId);
            a.get(max).setStmtId(node.getStmtId());
            a.get(max).setNoId(node.noId);
            regId++;
            produceMiddle(a.get(max));//特殊
        }
    }
    public static void generateLVal(TreeNode node){
        // LVal → Ident {'[' Exp ']'}
        ArrayList<TreeNode> childrenList=node.children;
        TreeNode ident = childrenList.get(0);
        String identName=ident.getContent();
        ValueDetail k = ident.getKey();
        int check=0;
        for(int i=stack.size()-1;i>=0;i--){
            if(stack.get(i).getContent().equals(identName)){
                k=stack.get(i).getKey();
                if(childrenList.size()==1){
                    if(stack.get(i).getKey().dimension ==0){//int a;
                        addLineToLLVM(tabLine()+"%v"+regId+" = load i32, i32* "+stack.get(i).getRegId());
                        k.setAddressType("i32");
                        node.setValue("%v"+regId);
                        node.setRegId(stack.get(i).getRegId());
                        regId++;
                    }
                    else if(stack.get(i).getKey().dimension ==1){
                        if(k.d1!=0){//int a[2]{func(a)}
                            addLineToLLVM(tabLine()+"%v"+regId+" = getelementptr ["+k.d1+" x i32], ["+k.d1+" x i32]*"+stack.get(i).getRegId()+", i32 0, i32 0");
                            k.setAddressType("i32*");
                            node.setValue("%v"+(regId));
                            node.setRegId("%v"+(regId));
                            regId+=2;
                        }
                        else{//func(int a[]){func(a)}
                            k.setAddressType("i32*");
                            addLineToLLVM(tabLine()+"%v"+regId+" = load "+k.addressType +", "+k.addressType +" * "+stack.get(i).getRegId());
                            node.setValue("%v"+(regId));
                            node.setRegId("%v"+(regId));
                            regId+=1;
                        }
                    }
                    else if(stack.get(i).getKey().dimension ==2){
                        if(k.d1!=0){//int a[2][3]{func(a)}
                            addLineToLLVM(tabLine()+"%v"+regId+" = getelementptr ["+k.d1+" x ["+k.d2+" x i32]], ["+k.d1+" x ["+k.d2+" x i32]]*"+stack.get(i).getRegId()+", i32 0, i32 0");
                            k.setAddressType("["+k.d2+" x i32]*");
                            node.setValue("%v"+(regId));
                            node.setRegId("%v"+(regId));
                            regId++;
                        }
                        else{//func(int a[][3]){func(a)}
                            addLineToLLVM(tabLine()+"%v"+regId+" = load ["+k.d2+" x i32] *, ["+k.d2+" x i32]* * "+stack.get(i).getRegId());
                            k.setAddressType("["+k.d2+" x i32]*");
                            node.setValue("%v"+(regId));
                            node.setRegId(stack.get(i).getRegId());
                            regId++;
                        }
                    }
                }
                else if(childrenList.size()==4){
                    if(stack.get(i).getKey().dimension ==1){
                        if(k.d1!=0){//int a[2]{func(a[1])}
                            produceMiddle(childrenList.get(2));
                            addLineToLLVM(tabLine()+"%v"+regId+" = getelementptr ["+k.d1+" x i32], ["+k.d1+" x i32]*"+stack.get(i).getRegId()+", i32 0, i32 "+childrenList.get(2).getValue());
                            addLineToLLVM(tabLine()+"%v"+(regId+1)+" = load i32, i32* %v"+regId);
                            k.setAddressType("i32");
                            node.setValue("%v"+(regId+1));
                            node.setRegId("%v"+(regId));
                            regId+=2;
                        }
                        else{//func(int b,int a[]){func(a[2],xxx)}
                            produceMiddle(childrenList.get(2));
                            addLineToLLVM(tabLine()+"%v"+regId+" = load i32*, i32* * "+stack.get(i).getRegId());
                            addLineToLLVM(tabLine()+"%v"+(regId+1)+" = getelementptr i32, i32* %v"+regId+", i32 "+childrenList.get(2).getValue());
                            addLineToLLVM(tabLine()+"%v"+(regId+2)+" = load i32, i32* %v"+(regId+1));
                            node.setValue("%v"+(regId+2));
                            node.setRegId("%v"+(regId+1));
                            k.setAddressType("i32");
                            regId+=3;
                        }
                    }
                    else if(stack.get(i).getKey().dimension ==2){
                        if(k.d1!=0){//int a[2][3]{func(a[1])}
                            produceMiddle(childrenList.get(2));
                            addLineToLLVM(tabLine()+"%v"+regId+" = mul i32 "+childrenList.get(2).getValue()+", "+k.d2);
                            regId++;
                            addLineToLLVM(tabLine()+"%v"+regId+" = getelementptr ["+k.d1+" x ["+k.d2+" x i32]], ["+k.d1+" x ["+k.d2+" x i32]]*"+stack.get(i).getRegId()+", i32 0, i32 0");
                            regId++;
                            addLineToLLVM(tabLine()+"%v"+regId+" = getelementptr ["+k.d2+" x i32], ["+k.d2+" x i32]* %v"+(regId-1)+", i32 0, i32 %v"+(regId-2));
                            k.setAddressType("i32*");
                            node.setValue("%v"+(regId));
                            node.setRegId("%v"+(regId));
                            regId+=1;
                        }
                        else{//func(int b[],int a[][3]){func(a[2],xxx)}
                            produceMiddle(childrenList.get(2));
                            addLineToLLVM(tabLine()+"%v"+regId+" = load ["+k.d2+" x i32] *, ["+k.d2+" x i32]* * "+stack.get(i).getRegId()+"\n");
                            regId++;
                            addLineToLLVM(tabLine()+"%v"+regId+" = getelementptr ["+k.d2+" x i32], ["+k.d2+" x i32]* %v"+(regId-1)+", i32 "+childrenList.get(2).getValue()+"\n");
                            regId++;
                            addLineToLLVM(tabLine()+"%v"+regId+" = getelementptr ["+k.d2+" x i32], ["+k.d2+" x i32]* %v"+(regId-1)+", i32 0, i32 0\n");
                            k.setAddressType("i32*");
                            node.setValue("%v"+(regId));
                            node.setRegId("%v"+(regId));
                            regId++;
                        }
                    }
                }
                else if(childrenList.size()==7){
                    produceMiddle(childrenList.get(2));
                    produceMiddle(childrenList.get(5));
                    if(k.d1!=0){//int a[2][3]{func(a[1][2])}
                        addLineToLLVM(tabLine()+"%v"+regId+" = getelementptr ["+k.d1+" x ["+k.d2+" x i32]], ["+k.d1+" x ["+k.d2+" x i32]]*"+stack.get(i).getRegId()+", i32 0, i32 "+childrenList.get(2).getValue()+", i32 "+childrenList.get(5).getValue()+"\n");
                        addLineToLLVM(tabLine()+"%v"+(regId+1)+" = load i32, i32* %v"+regId+"\n");
                        k.setAddressType("i32");
                        node.setValue("%v"+(regId+1));
                        node.setRegId("%v"+(regId));
                        regId+=2;
                    }
                    else{//func(int b,int a[][3]){func(a[2][2],xxx)}
                        addLineToLLVM(tabLine()+"%v"+regId+" = load ["+k.d2+" x i32] *, ["+k.d2+" x i32]* * "+stack.get(i).getRegId()+"\n");
                        regId++;
                        addLineToLLVM(tabLine()+"%v"+regId+" = getelementptr ["+k.d2+" x i32], ["+k.d2+" x i32]* %v"+(regId-1)+", i32 "+childrenList.get(2).getValue()+"\n");
                        regId++;
                        addLineToLLVM(tabLine()+"%v"+regId+" = getelementptr ["+k.d2+" x i32], ["+k.d2+" x i32]* %v"+(regId-1)+", i32 0, i32 "+childrenList.get(5).getValue()+"\n");
                        addLineToLLVM(tabLine()+"%v"+(regId+1)+" = load i32, i32 *%v"+(regId)+"\n");
                        k.setAddressType("i32");
                        node.setValue("%v"+(regId+1));
                        node.setRegId("%v"+(regId));
                        regId+=2;
                    }
                }
                check=1;
                break;
            }
        }
        if(check==0){
            k=global.get(identName).getKey();
            if(level>0){
                if(childrenList.size()==1){
                    if(k.dimension ==0){
                        addLineToLLVM(tabLine()+"%v"+regId+" = load i32, i32* @"+identName+"\n");
                        k.setAddressType("i32");
                        node.setValue("%v"+regId);
                        node.setRegId("@"+identName);
                        regId++;
                    }
                    else if(k.dimension ==1){
                        addLineToLLVM(tabLine()+"%v"+regId+" = getelementptr ["+k.d1+" x i32], ["+k.d1+" x i32]* @"+identName+", i32 0, i32 0\n");
                        k.setAddressType("i32*");
                        node.setValue("%v"+(regId));
                        node.setRegId("%v"+(regId));
                        regId+=2;
                    }
                    else if(k.dimension ==2){
                        addLineToLLVM(tabLine()+"%v"+regId+" = getelementptr ["+k.d1+" x ["+k.d2+" x i32]], ["+k.d1+" x ["+k.d2+" x i32]]* @"+identName+", i32 0, i32 0\n");
                        k.setAddressType("["+k.d2+" x i32]*");
                        node.setValue("%v"+(regId));
                        node.setRegId("%v"+(regId));
                        regId++;
                    }
                }
                else if(childrenList.size()==4){
                    if(k.dimension ==1){
                        produceMiddle(childrenList.get(2));
                        addLineToLLVM(tabLine()+"%v"+regId+" = getelementptr ["+k.d1+" x i32], ["+k.d1+" x i32]* @"+identName+", i32 0, i32 "+childrenList.get(2).getValue()+"\n");
                        addLineToLLVM(tabLine()+"%v"+(regId+1)+" = load i32, i32* %v"+regId+"\n");
                        k.setAddressType("i32");
                        node.setValue("%v"+(regId+1));
                        node.setRegId("%v"+(regId));
                        regId+=2;
                    }
                    else if(k.dimension ==2){
                        produceMiddle(childrenList.get(2));
                        addLineToLLVM(tabLine()+"%v"+regId+" = mul i32 "+childrenList.get(2).getValue()+", "+k.d2+"\n");
                        regId++;
                        addLineToLLVM(tabLine()+"%v"+regId+" = getelementptr ["+k.d1+" x ["+k.d2+" x i32]], ["+k.d1+" x ["+k.d2+" x i32]]* @"+identName+", i32 0, i32 0\n");
                        regId++;
                        addLineToLLVM(tabLine()+"%v"+regId+" = getelementptr ["+k.d2+" x i32], ["+k.d2+" x i32]* %v"+(regId-1)+", i32 0, i32 %v"+(regId-2)+"\n");
                        k.setAddressType("i32*");
                        node.setValue("%v"+(regId));
                        node.setRegId("%v"+(regId));
                        regId+=1;
                    }
                }
                else if(childrenList.size()==7){
                    produceMiddle(childrenList.get(2));
                    produceMiddle(childrenList.get(5));
                    addLineToLLVM(tabLine()+"%v"+regId+" = getelementptr ["+k.d1+" x ["+k.d2+" x i32]], ["+k.d1+" x ["+k.d2+" x i32]]* @"+identName+", i32 0, i32 "+childrenList.get(2).getValue()+", i32 "+childrenList.get(5).getValue()+"\n");
                    addLineToLLVM(tabLine()+"%v"+(regId+1)+" = load i32, i32* %v"+regId+"\n");
                    k.setAddressType("i32");
                    node.setValue("%v"+(regId+1));
                    node.setRegId("%v"+(regId));
                    regId+=2;
                }
            }
            else{
                if(childrenList.size()==1){
                    node.setValue(global.get(identName).getKey().getIntVal());
                }
                else if(childrenList.size()==4){
                    produceMiddle(childrenList.get(2));
                    node.setValue(global.get(identName).getKey().getD1Value()[Integer.parseInt(childrenList.get(2).getValue())]);
                }
                else if(childrenList.size()==7){
                    produceMiddle(childrenList.get(2));
                    produceMiddle(childrenList.get(5));
                    node.setValue(global.get(identName).getKey().getD2Value()[Integer.parseInt(childrenList.get(2).getValue())][Integer.parseInt(childrenList.get(5).getValue())]);
                }
            }
        }
        node.setKey(k);
    }
    public static void generateConstDef(TreeNode node){
        //ConstDef → Ident { '[' ConstExp ']' } '=' ConstInitVal
        ArrayList<TreeNode> childrenList=node.children;
        TreeNode ident = childrenList.get(0);
        ValueDetail k=ident.getKey();
        //Ident = ConstInitVal
        if(childrenList.size()==3){
            //System.out.println("whedbkjdkw");
            if(level!=0){
                addLineToLLVM(tabLine()+"%v"+regId+" = alloca i32");
                ident.setValue("%v"+regId);
                ident.setRegId("%v"+regId);
                regId++;
            }
            k.setDimension(0);
            childrenList.get(2).setKey(k);
            System.out.println("1221  "+childrenList.get(2).type);
            produceMiddle(childrenList.get(2));
            k.setIntVal(childrenList.get(2).getKey().getIntVal());
            if(level==0){
                addLineToLLVM("@"+ident.getContent()+" = dso_local global i32 "+k.getIntVal());
            }
            else{
                addLineToLLVM(tabLine()+"store i32 "+childrenList.get(2).getValue()+", i32* "+ident.getRegId());
            }
        }
        //Ident [ ConstExp ] = ConstInitVal
        else if(childrenList.size()==6){
            int l=level;
            level=0;
            produceMiddle(childrenList.get(2));
            level=l;
            if(level!=0){
                addLineToLLVM(tabLine()+"%v"+regId+" = alloca ["+childrenList.get(2).getValue()+" x i32]\n");
                ident.setValue("%v"+regId);
                ident.setRegId("%v"+regId);
                regId++;
            }
            k.setDim(1);
            k.setD1(Integer.parseInt(childrenList.get(2).getValue()));
            childrenList.get(5).setKey(k);
            produceMiddle(childrenList.get(5));

            if(level==0){
                addLineToLLVM("@"+ident.getContent()+" = dso_local constant ["+k.d1+" x i32] [");
                String []d1v = k.getD1Value();
                for(int i=0;i<k.d1-1;i++){
                    addLineToLLVM("i32 "+d1v[i]+", ");
                }
                addLineToLLVM("i32 "+k.getD1Value()[k.d1-1]+"]\n");
            }
            else{
                String []d1v = k.getD1Value();
                for(int i=0;i<k.d1;i++){
                    if(!(d1v[i].equals("NuLL"))){
                        addLineToLLVM(tabLine()+"%v"+regId+" = getelementptr ["+k.d1+" x i32], ["+k.d1+" x i32]*"+ident.getRegId()+", i32 0, i32 "+i+"\n");
                        addLineToLLVM(tabLine()+"store i32 "+d1v[i]+", i32* %v"+regId+"\n");
                        regId++;
                    }
                }
            }
        }
        else if(childrenList.size()==9){
            int l=level;
            level=0;
            produceMiddle(childrenList.get(2));
            produceMiddle(childrenList.get(5));
            level=l;
            if(level!=0){
                addLineToLLVM(tabLine()+"%v"+regId+" = alloca ["+childrenList.get(2).getValue()+" x [ "+childrenList.get(5).getValue() +" x i32]]\n");
                ident.setValue("%v"+regId);
                ident.setRegId("%v"+regId);
                regId++;
            }
            k.setDim(2);
            k.setD1(Integer.parseInt(childrenList.get(2).getValue()));
            k.setD2(Integer.parseInt(childrenList.get(5).getValue()));
            childrenList.get(8).setKey(k);
            produceMiddle(childrenList.get(8));
            if(level==0){
                addLineToLLVM("@"+ident.getContent()+" = dso_local constant ["+k.d1+" x ["+k.d2+" x i32]] [[");
                String [][]d2v = k.getD2Value();
                for(int i=0;i<k.d1-1;i++){
                    addLineToLLVM(k.d2+" x i32] [");
                    for(int j=0;j<k.d2-1;j++){
                        addLineToLLVM("i32 "+d2v[i][j]+", ");
                    }
                    addLineToLLVM("i32 "+k.getD2Value()[i][k.d2-1]+"], [");
                }
                addLineToLLVM(k.d2+" x i32] [");
                for(int j=0;j<k.d2-1;j++){
                    addLineToLLVM("i32 "+d2v[k.d1-1][j]+", ");
                }
                addLineToLLVM("i32 "+k.getD2Value()[k.d1-1][k.d2-1]+"]]\n");
            }
            else{
                String [][]d2v = k.getD2Value();
                for(int i=0;i<k.d1;i++){
                    for(int j=0;j<k.d2;j++){
                        if(!(d2v[i][j].equals("NuLL"))){
                            addLineToLLVM(tabLine()+"%v"+regId+" = getelementptr ["+k.d1+" x ["+k.d2+" x i32]], ["+k.d1+" x ["+k.d2+" x i32]]*"+ident.getRegId()+", i32 0, i32 "+i+", i32 "+j+"\n");
                            addLineToLLVM(tabLine()+"store i32 "+d2v[i][j]+", i32* %v"+regId+"\n");
                            regId++;
                        }
                    }
                }
            }
        }
        ident.setKey(k);
        if(level==0){
            global.put(ident.getContent(),ident);
        }
        else{
            ident.setLevel(level);
            stack.add(ident);
        }
    }
    public static void generateConstInitVal(TreeNode node){
        System.out.println("kjsdnakjdk"+node.getKey().intVal);
        ArrayList<TreeNode> childrenList=node.children;
        ValueDetail k= node.getKey();
        if(k.dimension ==0){
            produceMiddle(childrenList.get(0));
            node.getKey().setIntVal(childrenList.get(0).getValue());
            node.setValue(childrenList.get(0).getValue());
            System.out.println("kjsdnakjdk"+node.getKey().intVal);
        }
        else if(k.dimension ==1){
            int j=0;
            String[] d1v = k.d1Value;
            for(int i=1;i<childrenList.size()-1;i+=2){
                ValueDetail k1=childrenList.get(i).getKey();
                k1.setDimension(0);
                childrenList.get(i).setKey(k1);
                produceMiddle(childrenList.get(i));
                d1v[j]=childrenList.get(i).getValue();
                j++;
            }
            if(j<k.d1){
                for(;j<k.d1;j++){
                    if(level!=0){d1v[j]="NuLL";}
                    else{d1v[j]="0";}
                }
            }
            k.d1Value=d1v;
        }
        else if(k.dimension ==2){
            int m=0;
            String[][] d2v = k.getD2Value();
            if(childrenList.get(1).children.get(0).type.equals("LBRACE")){
                for(int i=1;i<childrenList.size()-1;i+=2){
                    ValueDetail k1=childrenList.get(i).getKey();
                    k1.setDimension(1);
                    k1.setD1(k.d2);
                    childrenList.get(i).setKey(k1);
                    produceMiddle(childrenList.get(i));
                    String[] d=childrenList.get(i).getKey().getD1Value();
                    for(int n=0;n<childrenList.get(i).getKey().d1;n++){
                        d2v[m][n]=d[n];
                    }
                    m++;
                }
            }
            else{
                int j=0;
                for(int i=1;i<childrenList.size()-1;i+=2){
                    ValueDetail k1=childrenList.get(i).getKey();
                    k1.setDimension(0);
                    childrenList.get(i).setKey(k1);
                    produceMiddle(childrenList.get(i));
                    d2v[0][j]=childrenList.get(i).getValue();
                    j++;
                }
                if(j<k.d1){
                    for(;j<k.d1;j++){
                        if(level!=0){d2v[0][j]="NuLL";}
                        else{d2v[0][j]="0";}
                    }
                }
            }
            if(m<k.d1){
                for(;m<k.d1;m++){
                    for(int n=0;n<k.d2;n++){
                        if(level!=0){d2v[m][n]="NuLL";}
                        else{d2v[m][n]="0";}
                    }
                }
            }
        }
    }
    public static void generateConstExp(TreeNode node){
        ArrayList<TreeNode> childrenList=node.children;
        if(childrenList.size()==1){
            produceMiddle(childrenList.get(0));
            node.setValue(childrenList.get(0).getValue());
        }
    }
    public static void generateVarDef(TreeNode node){
        ArrayList<TreeNode> childrenList=node.children;
        TreeNode ident = childrenList.get(0);
        ValueDetail k=ident.getKey();
        //Ident = InitVal | Ident
        if(childrenList.size()==1||childrenList.size()==3){
            //如果不是全局变量，就要allocate
            if(level!=0){
                addLineToLLVM(tabLine()+"%v"+regId+" = alloca i32");
                ident.setValue("%v"+regId);
                ident.setRegId("%v"+regId);
                regId++;
            }
            k.setDimension(0);
            if(childrenList.size()==3){
                produceMiddle(childrenList.get(2));
                k.setIntVal(childrenList.get(2).getKey().getIntVal());
                if(level!=0){
                    addLineToLLVM(tabLine()+"store i32 "+childrenList.get(2).getValue()+", i32* "+ident.getRegId());
                }
            }
            else if(childrenList.size()==1){
                k.setIntVal("0");
            }
            if(level==0){
                addLineToLLVM("@"+ident.getContent()+" = dso_local global i32 "+k.getIntVal());
            }
        }
        //Ident [ ConstExp ] = InitVal | Ident [ ConstExp ]
        else if(childrenList.size()==4||childrenList.size()==6){
            int l=level;
            level=0;
            produceMiddle(childrenList.get(2));
            level=l;
            if(level!=0){
                addLineToLLVM(tabLine()+"%v"+regId+" = alloca ["+childrenList.get(2).getValue()+" x i32]\n");
                ident.setValue("%v"+regId);
                ident.setRegId("%v"+regId);
                regId++;
            }
            k.setDim(1);
            k.setD1(Integer.parseInt(childrenList.get(2).getValue()));
            String []d1v = k.getD1Value();
            if(childrenList.size()==6){
                childrenList.get(5).setKey(k);
                produceMiddle(childrenList.get(5));
            }
            else if(childrenList.size()==4){
                for(int i=0;i<k.d1;i++){
                    if(level==0){d1v[i]="0";}
                    else{d1v[i]="NuLL";}
                }
                k.setD1Value(d1v);
            }
            if(level==0){
                if(childrenList.size()==6){
                    addLineToLLVM("@"+ident.getContent()+" = dso_local global ["+k.d1+" x i32] [");
                    d1v=k.getD1Value();
                    for(int i=0;i<k.d1-1;i++){
                        addLineToLLVM("i32 "+d1v[i]+", ");
                    }
                    addLineToLLVM("i32 "+k.getD1Value()[k.d1-1]+"]\n");
                }
                else{
                    addLineToLLVM("@"+ident.getContent()+" = dso_local global ["+k.d1+" x i32] zeroinitializer\n");
                }
            }
            else{
                d1v = k.getD1Value();
                for(int i=0;i<k.d1;i++){
                    if(!(d1v[i].equals("NuLL"))){
                        addLineToLLVM(tabLine()+"%v"+regId+" = getelementptr ["+k.d1+" x i32], ["+k.d1+" x i32]*"+ident.getRegId()+", i32 0, i32 "+i+"\n");
                        addLineToLLVM(tabLine()+"store i32 "+d1v[i]+", i32* %v"+regId+"\n");
                        regId++;
                    }
                }
            }
        }
        else if(childrenList.size()==7||childrenList.size()==9){
            int l=level;
            level=0;
            produceMiddle(childrenList.get(2));
            produceMiddle(childrenList.get(5));
            level=l;
            if(level!=0){
                addLineToLLVM(tabLine()+"%v"+regId+" = alloca ["+childrenList.get(2).getValue()+" x [ "+childrenList.get(5).getValue() +" x i32]]\n");
                ident.setValue("%v"+regId);
                ident.setRegId("%v"+regId);
                regId++;
            }
            k.setDim(2);
            k.setD1(Integer.parseInt(childrenList.get(2).getValue()));
            k.setD2(Integer.parseInt(childrenList.get(5).getValue()));
            String [][]d2v = k.getD2Value();
            if(childrenList.size()==9){
                childrenList.get(8).setKey(k);
                produceMiddle(childrenList.get(8));
            }
            else if(childrenList.size()==7){
                for(int i=0;i<k.d1;i++){
                    for(int j=0;j<k.d2;j++){
                        if(level==0){
                            d2v[i][j]="0";
                        }
                        else{
                            d2v[i][j]="NuLL";
                        }
                    }
                }
                k.setD2Value(d2v);
            }
            if(level==0){
                if(childrenList.size()==9){
                    addLineToLLVM("@"+ident.getContent()+" = dso_local global ["+k.d1+" x ["+k.d2+" x i32]] [[");
                    d2v=k.getD2Value();
                    for(int i=0;i<k.d1-1;i++){
                        addLineToLLVM(k.d2+" x i32] [");
                        for(int j=0;j<k.d2-1;j++){
                            addLineToLLVM("i32 "+d2v[i][j]+", ");
                        }
                        addLineToLLVM("i32 "+k.getD2Value()[i][k.d2-1]+"], [");
                    }
                    addLineToLLVM(k.d2+" x i32] [");
                    for(int j=0;j<k.d2-1;j++){
                        addLineToLLVM("i32 "+d2v[k.d1-1][j]+", ");
                    }
                    addLineToLLVM("i32 "+k.getD2Value()[k.d1-1][k.d2-1]+"]]\n");
                }
                else{
                    addLineToLLVM("@"+ident.getContent()+" = dso_local global ["+k.d1+" x ["+k.d2+" x i32]] zeroinitializer\n");
                }
            }
            else{
                d2v = k.getD2Value();
                for(int i=0;i<k.d1;i++){
                    for(int j=0;j<k.d2;j++){
                        if(!(d2v[i][j].equals("NuLL"))){
                            addLineToLLVM(tabLine()+"%v"+regId+" = getelementptr ["+k.d1+" x ["+k.d2+" x i32]], ["+k.d1+" x ["+k.d2+" x i32]]*"+ident.getRegId()+", i32 0, i32 "+i+", i32 "+j+"\n");
                            addLineToLLVM(tabLine()+"store i32 "+d2v[i][j]+", i32* %v"+regId+"\n");
                            regId++;
                        }
                    }
                }
            }
        }
        ident.setKey(k);
        if(level==0){
            global.put(ident.getContent(),ident);
        }
        else{
            ident.setLevel(level);
            stack.add(ident);
        }
    }
    public static void generateFuncDef(TreeNode node){
        ArrayList<TreeNode> childrenList=node.children;
        String Type = childrenList.get(0).children.get(0).getContent();
        TreeNode ident = childrenList.get(1);
        if(Type.equals("int")){Type="i32";}
        else if(Type.equals("void")){Type="void";}
        ident.setReturnType(Type);
        outputWithoutWarp("define dso_local "+Type+" @"+ident.getContent());
        global.put(ident.getContent(),ident);
        if(childrenList.get(2).type.equals("LPARENT")){
            outputWithoutWarp("(");
            if(childrenList.get(4).type.equals("RPARENT")){
                produceMiddle(childrenList.get(3));
                outputWithoutWarp(") {",1);
                produceMiddle(childrenList.get(5));
            }
            else{
                outputWithoutWarp(") {",1);
                produceMiddle(childrenList.get(4));
            }
        }
        if(Type.equals("void")){
            nowTag+=1;
            addLineToLLVM(tabLine()+"ret void");
            nowTag-=1;
        }
        addLineToLLVM("}");
    }
    public static void generateFuncFParams(TreeNode node){
        ArrayList<TreeNode> childrenList=node.children;
        produceMiddle(childrenList.get(0));
        for(int i=2;i<childrenList.size();i+=2){
            outputWithoutWarp(", ");
            produceMiddle(childrenList.get(i));
        }
    }
    public static void generateFuncFParam(TreeNode node){
        ArrayList<TreeNode> childrenList=node.children;
        TreeNode ident = childrenList.get(1);
        ident.setLevel(1);
        if(childrenList.size()==2){
            outputWithoutWarp("i32 %v"+regId);
            ident.setValue("%v"+regId);
            ident.getKey().setAddressType("i32");
            regId++;
            stack.add(ident);
        }
        else if(childrenList.size()==4){
            outputWithoutWarp("i32* %v"+regId);
            ident.setValue("%v"+regId);
            ident.getKey().setAddressType("i32*");
            ident.getKey().setDimension(1);
            ident.getKey().setD1(0);
            regId++;
            stack.add(ident);
        }
        else if(childrenList.size()==7){
            //constexp
            //System.out.println("SSSS"+childrenList.get(5).type);
            produceMiddle(childrenList.get(5));
            //System.out.println(childrenList.get(5).getValue()+ "QWEQWWEQE");
            outputWithoutWarp("["+childrenList.get(5).getValue()+" x i32] *%v"+regId);
            ident.setValue("%v"+regId);
            ident.getKey().setDimension(2);
            ident.getKey().setD1(0);
            ident.getKey().setD2(Integer.parseInt(childrenList.get(5).getValue()));
            ident.getKey().setAddressType("["+childrenList.get(5).getValue()+" x i32]*");
            regId++;
            stack.add(ident);
        }
    }
    public static void generateFuncRParams(TreeNode node){
        ArrayList<TreeNode> childrenList=node.children;
        produceMiddle(childrenList.get(0));
        StringBuilder Value;
        Value=new StringBuilder(childrenList.get(0).getKey().addressType +" "+childrenList.get(0).getValue());
        for(int i=2;i<childrenList.size();i+=2){
            produceMiddle(childrenList.get(i));
            Value.append(", ").append(childrenList.get(i).getKey().addressType).append(" ").append(childrenList.get(i).getValue());
        }
        node.setValue(Value.toString());
    }
    public static void generateForStmt(TreeNode node){
        //ForStmt → LVal '=' Exp
        ArrayList<TreeNode> a=node.children;
        produceMiddle(a.get(0));//LVal
        produceMiddle(a.get(2));//Exp
        addLineToLLVM(tabLine()+"store i32 "+a.get(2).getValue()+", i32* "+a.get(0).getRegId()+"\n");
        addLineToLLVM(tabLine()+"br label %v"+node.getStmtId()+"\n");
    }
    public static void generateCond(TreeNode node){
        node.children.get(0).setNoId(node.noId);
        node.children.get(0).setYesId(node.yesId);
        node.children.get(0).setStmtId(node.getStmtId());
        produceMiddle(node.children.get(0));//LOrExp
        node.setValue("%v"+regId);
        regId++;
    }
    //传入一个运算符，返回它所对应的llvm操作指令
    public static String opToOperation(String op){
        return switch (op) {
            case "+" -> "add";
            case "-" -> "sub";
            case "*" -> "mul";
            case "/" -> "sdiv";
            case "%" -> "srem";
            case "==" -> "eq";
            case "!=" -> "ne";
            case ">" -> "sgt";
            case ">=" -> "sge";
            case "<" -> "slt";
            case "<=" -> "sle";
            case "&&" -> "and";
            case "||" -> "or";
            default -> "";
        };
    }
    public static void generateNumber(TreeNode node){
        ArrayList<TreeNode> a=node.children;
        node.setValue(a.get(0).getContent());
    }
    public static int getLevel(TreeNode node){
        //最外层符号表的id为0
        int level = 0;
        int td = node.tableId;
        while(td!=0){
            td = tableList.get(td).fatherId;
        }
        return level;
    }
    public static void addLineToLLVM(String content){
        Line line = new Line(0,content);
        lineList.add(line);
    }
    public static void outputWithoutWarp(String content){
        stringStack.add(content);
    }
    public static void outputWithoutWarp(String content,int flag){
        stringStack.add(content);
        StringBuilder result = new StringBuilder();
        for (String str : stringStack) {
            result.append(str);
        }
        stringStack.clear();
        addLineToLLVM(result.toString());
    }
    public static String mathCalculate(String left,String op,String right){
        int a=Integer.parseInt(left);
        int b=Integer.parseInt(right);
        int ans=0;
        switch(op){
            case "+":ans=a+b;break;
            case "-":ans=a-b;break;
            case "*":ans=a*b;break;
            case "/":ans=a/b;break;
            case "%":ans=a%b;break;
            case "==": ans=(a==b)?1:0;break;
            case "!=": ans=(a!=b)?1:0;break;
            case ">": ans=(a>b)?1:0;break;
            case ">=": ans=(a>=b)?1:0;break;
            case "<": ans=(a<b)?1:0;break;
            case "<=": ans=(a<=b)?1:0;break;
        }
        return ans+"";
    }
    public static String tabLine(){
        return " ".repeat(Math.max(0, 4 * nowTag));
    }
}
