package line;

public class FuncDefLine extends Line{

    public FuncDefLine(int level, String content) {
        super(level, content);
    }
}
